"""Story rules ST-01..ST-19 (docs/STORY_ENGINE.md, D-48) on a production script's story layer (``drama`` at the top,
``drama`` per segment). Free, run by ``production validate`` before any paid step.

The creator's note on the first video (2026-10-19): the script told a less interesting story and missed what viewers
want; facts and basic human needs must be balanced. The rules turn screenwriting craft into checks a model can be held
to: one dramatic question, causality between beats (but / therefore, never "and then"), heroes with a want and a
flaw, rising stakes with a turn of value in every segment, open loops that are paid off, set-ups with pay-offs, the
needs the episode serves, and what is fact, reasoning or invention. Structure FAILs (a loop that does not exist, a
pay-off before its plant); craft is REVIEW (the creator judges the story). ST-14 frames every exchange (BP-90). The numbers and severities of ST-11, ST-12
and ST-13 live in the sourced rules registry (BP-74..BP-76, docs/SOURCED_RULES.md); ST-13 turns words into seconds at
BP-01's heard pace, the one pace every estimate uses. ST-17..ST-19 apply to template D, the historical docudrama
(``drama.template`` "D"; BP-104, BP-105).

    python -m explainer_engine.scripting.story_lint production_script.json
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from explainer_engine.scripting import variant_plan
from explainer_engine.scripting.syllables import seconds as spoken_seconds
from explainer_engine.standards import sourced_rules as SR

MIN_NEEDS = 3
MAX_UNANSWERED_QUESTIONS = SR.T("BP-74", "stacked_questions_min")  # ST-11 (D-49)
MAX_AND_THEN_SHARE = 0.0
TURN_FUNCS = {"reversal", "midpoint", "crisis", "twist", "climax"}
OPENERS = {"cold_open", "hook"}
AND_THEN = re.compile(r"^\s*(and then|after that|next,|then,|also,)", re.I)
SCENE_SCHEMA = "production_script/3"  # the 2026-10-19 scene rewrite: a missing drama is a FAIL, ST-12/ST-13 apply
MIDPOINT_BAND = tuple(SR.T("BP-75", "midpoint_share"))  # ST-12: the midpoint/reversal sits at 40-60 % of the words
MIDPOINT_MIN_SEGMENTS = SR.T("BP-75", "min_segments")
TURN_GAP_S = SR.T("BP-76", "turn_gap_s")  # ST-13: a turn at least this often
WORDS_PER_S = SR.T("BP-01", "wpm_target") / 60  # ST-13: words become seconds at BP-01's heard pace
SETUP_MIN, CONCLUSION_MIN = SR.T("BP-90", "setup_lines_min"), SR.T("BP-90", "conclusion_lines_min")  # ST-14 (RX-03)
SPEECH_VERBS = tuple(SR.T("BP-70", "speech_verbs"))  # reported speech (D-63): "Musk says...", "he asks..."
REPORTED_SPEAKERS_MAX = SR.T("BP-96", "speakers_max")  # ST-16 (NR-04, a hypothesis)
_VERB = "(?:" + "|".join(SPEECH_VERBS) + ")"
DOCUDRAMA = "D"  # template D, the historical docudrama (docs/STORY_ENGINE.md): ST-17..ST-19 and ST-24 apply
D_ROWS = 16  # template D has 16 rows; its turn slots (BP-142) are rows of that table
NARRATION_BLOCK_MAX_S = SR.T("BP-104", "narration_block_max_s")  # ST-17
NARRATOR_SHARE = tuple(SR.T("BP-105", "narrator_share"))  # ST-19
CENTRAL_FUNCS = {"climax", "crisis", "midpoint"}  # ST-18: the central scene
AND_THEN_CHAIN = SR.T("BP-145", "chain_min")  # ST-20 (P3)
OVERLAP_MAX = SR.T("BP-144", "overlap")  # ST-21, and KP-20 on a shot card
AD_WINDOW_S = SR.T("BP-143", "window_s")  # ST-22
VIOLENCE = re.compile(r"\b(?:" + "|".join(re.escape(w) for w in SR.T("BP-143", "lexicon")) + ")", re.I)
TWIST_MAX_S = SR.T("BP-115", "twist_max_s")  # ST-23
PROMISE_PAID_BY_S = SR.T("BP-135", "promise_paid_by_s")  # the first packaging promise is paid in the first seconds
TWIST_FUNCS = {"twist", "reversal"}
_STOP = set("a an the and or but of to in on at by for with from his her their its it he she they them this that is are was were be "
            "been as so if then than too very not no we you your our i me my up out over into onto off all any each one two".split())


def sev(rule_id: str) -> str:
    """A registered rule's severity is the registry's (BP-74..BP-76)."""
    return SR.rule(rule_id).get("severity", "REVIEW")


def _f(out, rule, where, detail, sev="REVIEW"):
    out.append({"rule": rule, "severity": sev, "where": where, "detail": detail})


def lint(doc: dict) -> list[dict]:
    out: list[dict] = []
    drama = doc.get("drama")
    segs = doc.get("segments", [])
    if not drama:
        # Syndicate Wars shipped without a drama block and this single REVIEW was the only trace; on /3 it blocks (D-58)
        _f(out, "ST-00", "drama", "no story layer: write drama (premise, question, promise, arcs, loops) before the lines",
           "FAIL" if doc.get("schema") == SCENE_SCHEMA else "REVIEW")
        return out
    order = {s["id"]: i for i, s in enumerate(segs)}
    sd = [(s["id"], s.get("drama")) for s in segs]
    missing = [sid for sid, d in sd if not d]
    if missing:
        _f(out, "ST-00", ",".join(missing[:6]), f"{len(missing)} segment(s) without drama (function, turn)")
    # ST-01 one dramatic question, asked in the opening, answered at the end
    first = next((d for _, d in sd if d), None)
    if first and first["function"] not in OPENERS:
        _f(out, "ST-01", segs[0]["id"], "the first segment is not a cold open or hook: the question must be asked at once")
    if not drama["question"].rstrip().endswith("?"):
        _f(out, "ST-01", "drama.question", "the dramatic question is not a question")
    last = next((d for _, d in reversed(sd) if d), None)
    if last and last["function"] not in {"resolution", "button", "twist", "climax"}:
        _f(out, "ST-01", segs[-1]["id"], "the last segment does not resolve the dramatic question")
    # ST-02 causality: but / therefore, never and-then
    for i, (sid, d) in enumerate(sd):
        if not d:
            continue
        if i and d["turn"] == "start":
            _f(out, "ST-02", sid, "only the first segment may be 'start'; later ones follow by BUT or THEREFORE")
        lines = segs[i].get("lines", [])
        if i and lines and AND_THEN.match(lines[0]["text"]):
            _f(out, "ST-02", sid, f"opens with {lines[0]['text'][:24]!r}: an 'and then' join; give the cause (but / therefore)")
    turns = [d["turn"] for _, d in sd[1:] if d]
    if turns and turns.count("but") < max(1, len(turns) // 4):
        _f(out, "ST-02", "segments", f"{turns.count('but')} BUT turn(s) in {len(turns)} joins: without obstacles the story only lists "
           "(about one join in three is a BUT)")
    # ST-03 stakes and a turn of value in every segment
    for sid, d in sd:
        if d and d["function"] not in OPENERS and not d.get("stakes"):
            _f(out, "ST-03", sid, "no stakes: say what is lost if this goes wrong")
        if d and d["function"] not in {"button"} and not d.get("shift"):
            _f(out, "ST-03", sid, "no value turns (shift 'safe -> hunted'): a segment where nothing changes is cut or merged")
    # ST-04 heroes: a want and a flaw, and they speak
    arcs = drama.get("arcs", {})
    cast = doc.get("cast", {})
    for who in arcs:
        if who not in cast:
            _f(out, "ST-04", who, "arc for someone not in the cast", "FAIL")
    speakers = {ln.get("speaker") for s in segs for ln in s.get("lines", []) if ln.get("speaker")}
    for who in speakers:
        if who not in arcs:
            _f(out, "ST-04", who, "a speaking hero without an arc (want, flaw): their lines have nothing to push against")
    if not arcs:
        _f(out, "ST-04", "drama.arcs", "no hero arcs: a what-if needs someone who wants something in it")
    # ST-05 open loops opened and paid off in order, none left hanging
    loops = {lp["id"]: lp for lp in drama.get("loops", [])}
    opened, closed = {}, {}
    for sid, d in sd:
        for lid in (d or {}).get("opens", []):
            if lid not in loops:
                _f(out, "ST-05", sid, f"opens unknown loop {lid}", "FAIL")
            opened.setdefault(lid, sid)
        for lid in (d or {}).get("closes", []):
            if lid not in loops:
                _f(out, "ST-05", sid, f"closes unknown loop {lid}", "FAIL")
            elif lid not in opened:
                _f(out, "ST-05", sid, f"closes {lid} before it is opened", "FAIL")
            closed.setdefault(lid, sid)
    for lid in loops:
        if lid in opened and lid not in closed:
            _f(out, "ST-05", opened[lid], f"loop {lid} ({loops[lid]['question'][:40]!r}) is never paid off")
        if lid not in opened:
            _f(out, "ST-05", "drama.loops", f"loop {lid} is never opened")
    for i, (sid, d) in enumerate(sd[:-1]):
        if d and d["function"] not in {"resolution", "button"}:
            still_open = [x for x in opened if order[opened[x]] <= i and (x not in closed or order[closed[x]] > i)]
            if not still_open:
                _f(out, "ST-05", sid, "no loop is open at the end of this segment: nothing pulls the viewer into the next one")
    # ST-06 set-ups and pay-offs
    for p in drama.get("setups", []):
        if p["plant"] not in order or p["payoff"] not in order:
            _f(out, "ST-06", p["id"], "plant or pay-off segment does not exist", "FAIL")
        elif order[p["payoff"]] <= order[p["plant"]]:
            _f(out, "ST-06", p["id"], "paid off before (or where) it is planted", "FAIL")
    if len(segs) >= 6 and not drama.get("setups"):
        _f(out, "ST-06", "drama.setups", "no set-up / pay-off pair: plant one early detail that decides the end")
    # ST-07 turning points spread through the story
    funcs = [d["function"] for _, d in sd if d]
    if len(funcs) >= 6:
        n_turn = sum(f in TURN_FUNCS for f in funcs)
        if n_turn < 2:
            _f(out, "ST-07", "segments", f"{n_turn} turning point(s) (reversal, midpoint, crisis, twist, climax): at least 2")
        third = len(funcs) // 3
        if not any(f in TURN_FUNCS for f in funcs[third:2 * third + 1]):
            _f(out, "ST-07", "segments", "no turn in the middle third: the middle sags")
    # ST-08 human needs
    needs = drama.get("needs", [])
    if len(needs) < MIN_NEEDS:
        _f(out, "ST-08", "drama.needs", f"{len(needs)} need(s) served; name at least {MIN_NEEDS} (curiosity, stakes, humour, wonder...)")
    used = {d.get("need") for _, d in sd if d and d.get("need")}
    for n in needs:
        if n not in used:
            _f(out, "ST-08", "drama.needs", f"need {n!r} is promised but no segment serves it")
    # ST-09 objectivity: what carries each segment is labelled; invention is never the majority, facts carry claims
    shares = [d.get("claim_share") for _, d in sd if d and d.get("claim_share")]
    if shares and shares.count("invented") > len(shares) / 2:
        _f(out, "ST-09", "segments", f"{shares.count('invented')} of {len(shares)} segments are invention: the what-if must stand on facts")
    for i, (sid, d) in enumerate(sd):
        if d and d.get("claim_share") == "fact" and not any(ln.get("claims") for ln in segs[i].get("lines", [])):
            _f(out, "ST-09", sid, "labelled fact but no line carries a claim id", "FAIL")
    # ST-11 a question outside a declared loop is answered within seconds (the curiosity boost fades in 6-8 s);
    # three or more questions in one segment that opens no loop are stacked, not answered
    for i, (sid, d) in enumerate(sd):
        qs = sum(1 for ln in segs[i].get("lines", []) if ln["text"].rstrip().endswith("?"))
        if qs >= MAX_UNANSWERED_QUESTIONS and not (d or {}).get("opens"):
            _f(out, "ST-11", sid, f"{qs} questions in one segment that opens no loop: answer each within a few seconds or declare the "
               "loop (BP-74)", sev("BP-74"))
    # ST-10 the ending pays the promise
    end = drama.get("ending")
    if not end:
        _f(out, "ST-10", "drama.ending", "no ending kind (twist, reversal, bookend, callback, open question)")
    # ST-12 / ST-13 (the 2026-10-19 rewrite): the midpoint sits mid-script and turns arrive on a cadence.
    # Word counts stand in for the clock at write time (the read decides later); both are craft, so REVIEW.
    seg_words = [sum(len(ln["text"].split()) for ln in s.get("lines", [])) for s in segs]
    total = sum(seg_words)
    if total and len(segs) >= MIDPOINT_MIN_SEGMENTS:
        cum = 0.0
        mid_shares = []
        for (sid, d), w in zip(sd, seg_words):
            at = (cum + w / 2) / total
            cum += w
            if d and d["function"] in {"midpoint", "reversal"}:
                mid_shares.append((sid, at))
        if mid_shares and not any(MIDPOINT_BAND[0] <= at <= MIDPOINT_BAND[1] for _, at in mid_shares):
            sid, at = min(mid_shares, key=lambda x: abs(x[1] - 0.5))
            _f(out, "ST-12", sid, f"the midpoint/reversal sits at {at:.0%} of the words (aim "
               f"{MIDPOINT_BAND[0]:.0%}-{MIDPOINT_BAND[1]:.0%}, BP-75): the pivot belongs mid-story", sev("BP-75"))
    if total:
        gap_words, gap_from = 0.0, None
        budget = TURN_GAP_S * WORDS_PER_S
        for (sid, d), w in zip(sd, seg_words):
            is_turn = bool(d) and (d["function"] in TURN_FUNCS or d.get("turn") == "but")
            if is_turn or (d and d["function"] in {"resolution", "button"}):
                gap_words, gap_from = 0.0, None
                continue
            gap_from = gap_from or sid
            gap_words += w
            if gap_words > budget:
                _f(out, "ST-13", f"{gap_from}..{sid}", f"about {gap_words / WORDS_PER_S:.0f} s at {WORDS_PER_S * 60:g} wpm "
                   f"without a turn (a BUT, reversal, midpoint, crisis, twist or climax): something must change at least every "
                   f"{TURN_GAP_S:g} s (BP-76)", sev("BP-76"))
                gap_words, gap_from = 0.0, None
    out += exchanges(doc)
    out += reported_speech(doc)
    out += script_checks(doc, segs, sd)
    if drama.get("template") == DOCUDRAMA:
        _docudrama(out, segs, sd, seg_words)
        out += turns_played(doc, segs)
    return out


def turns_played(doc: dict, segs: list[dict]) -> list[dict]:
    """ST-24 (BP-142, house): every turn of a docudrama is a played scene: a turn slot with no hero line is a FAIL, a played share
    under the profile's minimum (BP-141) is REVIEW. Template D's slot ids (rows 4, 6, 8, 10, 11, 13) are used only when the script
    has template D's 16 rows; any other script is held to its segments whose function is a turn."""
    prof = variant_plan.profile((doc.get("drama") or {}).get("profile_id") or DOCUDRAMA)
    dyn = variant_plan.dynamics(variant_plan.segments_from_script(doc), prof, template=DOCUDRAMA if len(segs) == D_ROWS else "any")
    return [dict(f, rule="ST-24") for f in variant_plan.turn_findings(dyn, prof)]


def content_words(text: str) -> set[str]:
    """The words of a line that carry its content (no articles, pronouns or auxiliaries; at least three letters)."""
    return {w for w in re.findall(r"[a-z']+", text.lower()) if w not in _STOP and len(w) > 2}


def overlap(said: set[str], seen: set[str]) -> float:
    """The share of ``said`` already in ``seen``: the one measure of double exposition (ST-21 on lines, KP-20 on a shot card)."""
    return len(said & seen) / len(said) if said else 0.0


def line_starts(segs: list[dict]) -> list[tuple[dict, int, float]]:
    """(segment, line index, estimated start second) for every line, on ``syllables.spoken_seconds`` plus the planned pauses."""
    t, out = 0.0, []
    for seg in segs:
        for k, ln in enumerate(seg.get("lines", [])):
            out.append((seg, k, t))
            t += spoken_seconds(ln["text"], pause_after=float(ln.get("pause_after", 0) or 0))
    return out


def script_checks(doc: dict, segs: list, sd: list) -> list[dict]:
    """ST-20 an and-then chain, ST-21 double exposition, ST-22 the ad-safety window, ST-23 the twist lands, and the first
    packaging promise paid in the first seconds (BP-135). All hypotheses: REVIEW."""
    out: list[dict] = []
    # ST-20: AND_THEN joins in one segment's narrator lines, or on two consecutive segment openers
    opener = []
    for i, seg in enumerate(segs):
        lines = seg.get("lines", [])
        joins = [k for k, ln in enumerate(lines, 1) if not ln.get("speaker") and AND_THEN.match(ln["text"])]
        if len(joins) >= AND_THEN_CHAIN:
            _f(out, "ST-20", seg["id"], f"{len(joins)} lines open with 'and then', 'after that' or 'next': a chain of events, not of "
               "causes; give each join its but or therefore (BP-145)", sev("BP-145"))
        opener.append(bool(i and lines and AND_THEN.match(lines[0]["text"])))
        if i and opener[i] and opener[i - 1]:
            _f(out, "ST-20", f"{segs[i - 1]['id']}..{seg['id']}", "two segments in a row open with an 'and then' join (BP-145)",
               sev("BP-145"))
    # ST-21: a narrator line that says again what the adjacent character line just played
    for seg in segs:
        lines = seg.get("lines", [])
        for k, ln in enumerate(lines):
            if ln.get("speaker"):
                continue
            said = content_words(ln["text"])
            near = [lines[j] for j in (k - 1, k + 1) if 0 <= j < len(lines) and lines[j].get("speaker")]
            if len(said) >= 4 and near and overlap(said, content_words(" ".join(n["text"] for n in near))) >= OVERLAP_MAX:
                _f(out, "ST-21", f"{seg['id']} line {k + 1}", "the narrator repeats what the scene just played: give the narrator what "
                   "the heroes cannot know (BP-144)", sev("BP-144"))
    starts = line_starts(segs)
    # ST-22: graphic violence inside the first seconds of the video
    for seg, k, t in starts:
        if t >= AD_WINDOW_S:
            break
        if VIOLENCE.search(seg["lines"][k]["text"]):
            _f(out, "ST-22", f"{seg['id']} line {k + 1}", f"a graphic-violence word at about {t:.1f} s: YouTube's ad guidance names the "
               f"first {AD_WINDOW_S:g} seconds (BP-143); the creator decides", sev("BP-143"))
    # ST-23: the first line of a twist or reversal segment is short enough to land
    for (sid, d), seg in zip(sd, segs):
        if d and d["function"] in TWIST_FUNCS and seg.get("lines"):
            secs = spoken_seconds(seg["lines"][0]["text"])
            if secs > TWIST_MAX_S:
                _f(out, "ST-23", f"{sid} line 1", f"the turn takes about {secs:.1f} s to say (more than {TWIST_MAX_S:g} s, BP-115): "
                   "cut it to the sentence that turns, or give the turn its own short sentence", sev("BP-115"))
    # BP-135: the first packaging promise is paid inside the first seconds (when the stage 1b promises are on the script)
    promises = (doc.get("drama") or {}).get("packaging_promises")
    if promises and starts:
        stems = {w[:5] for w in content_words(promises[0]) if len(w) >= 5}
        early = " ".join(w for w in (seg["lines"][k]["text"].lower() for seg, k, t in starts if t < PROMISE_PAID_BY_S))
        if stems and not any(re.search(r"\b" + re.escape(st), early) for st in stems):
            _f(out, "ST-01", "drama.packaging_promises", f"the first promise ({promises[0][:50]!r}) is not paid by a word in the first "
               f"{PROMISE_PAID_BY_S:g} s (BP-135): the title and thumbnail promise must show up at once", sev("BP-135"))
    return out


def _name_alt(names: list[str]) -> str:
    return "|".join(re.escape(n) for n in sorted(names, key=len, reverse=True))


def reported_turns(text: str, cast: dict, who: list[str] | None = None) -> list[str]:
    """The turns a narrator line reports (BP-70, D-63): each "<name> <verb>" (``Musk says``, ``O'Leary asks``) is a turn of
    that hero, each "he/she <verb>" a turn of the last hero named. ``who`` limits it to those cast ids (a scene's present)."""
    ids = list(who or cast)
    pats = [(h, _name_alt(list(cast.get(h, {}).get("names") or [h]))) for h in ids]
    names = "|".join(f"(?P<h{i}>{p})" for i, (_, p) in enumerate(pats) if p)
    if not names:
        return []
    verb = re.compile(rf"\s+(?:\w+ly\s+)?{_VERB}\b")
    out, last = [], None
    for m in re.finditer(rf"\b(?:{names}|(?P<pro>he|she))\b", text, re.I):
        hit = next((pats[i][0] for i in range(len(pats)) if m.groupdict().get(f"h{i}")), None)
        if not verb.match(text, m.end()):
            last = hit or last  # a name without a verb: who "he" refers to next
            continue
        spk = hit or last
        if spk:
            out.append(spk)
            last = spk
    return out


def _named(text: str, names: list[str]) -> bool:
    low = " " + re.sub(r"[^a-z0-9' ]", " ", text.lower()) + " "
    return any(f" {n.lower()} " in low or f" {n.lower()}'s " in low for n in names)


def exchanges(doc: dict) -> list[dict]:
    """ST-14 (BP-90, RX-03; the creator 2026-10-20 21:14): an exchange is framed. In each segment the hero lines (voiced or
    bubble) are one exchange: before it at least SETUP_MIN narrator line, each speaker named by the narrator before his
    first line; after it at least CONCLUSION_MIN narrator line. A segment that ends or opens on a hero line chains two
    exchanges (no conclusion between them)."""
    out: list[dict] = []
    cast = doc.get("cast", {})
    for seg in doc.get("segments", []):
        lines = seg.get("lines", [])
        hero = [k for k, ln in enumerate(lines) if ln.get("speaker")]
        if not hero:
            continue
        first, last = hero[0], hero[-1]
        setup = [ln for ln in lines[:first] if not ln.get("speaker")]
        if len(setup) < SETUP_MIN:
            _f(out, "ST-14", f"{seg['id']} line {first + 1}", "the exchange opens without the narrator's setup: first say who "
               "talks and what idea or want brings them here (BP-90)", sev("BP-90"))
        for who in dict.fromkeys(lines[k]["speaker"] for k in hero):
            k0 = next(k for k in hero if lines[k]["speaker"] == who)
            told = " ".join(ln["text"] for ln in lines[:k0] if not ln.get("speaker"))
            if not _named(told, list(cast.get(who, {}).get("names") or [who])):
                _f(out, "ST-14", f"{seg['id']} line {k0 + 1}", f"{who} speaks before the narrator names him: the setup names "
                   "every speaker of the exchange (BP-90; REVIEW, a description may stand for the name)")
        if sum(1 for ln in lines[last + 1:] if not ln.get("speaker")) < CONCLUSION_MIN:
            _f(out, "ST-14", f"{seg['id']} line {last + 1}", "the exchange ends without the narrator's conclusion: say what came "
               "of it before anything else happens, never chain two exchanges (BP-90)", sev("BP-90"))
    return out


_TRAILING = re.compile(r"[,!?]\s*(?:" + _VERB + r"\s+(?P<a>[A-Z][\w']*(?:\s[A-Z][\w']*)?|he|she)|(?P<b>[A-Z][\w']*(?:\s[A-Z][\w']*)?|"
                       r"[Hh]e|[Ss]he)\s+" + _VERB + r")\s*[.!?]?\s*$")


def reported_speech(doc: dict) -> list[dict]:
    """ST-15 (BP-95, NR-02): a reported line names the speaker before his words, never in a trailing tag ("..., says Musk.").
    ST-16 (BP-96, NR-04): one narrator line reports at most REPORTED_SPEAKERS_MAX named speakers. Both REVIEW heuristics."""
    out: list[dict] = []
    cast = doc.get("cast", {})
    for seg in doc.get("segments", []):
        for k, ln in enumerate(seg.get("lines", []), 1):
            if ln.get("speaker"):
                continue
            where = f"{seg['id']} line {k}"
            for sent in re.split(r"(?<=[.!?])\s+", ln["text"].strip()):
                if _TRAILING.search(sent):
                    _f(out, "ST-15", where, f"{sent[:60]!r}: the speaker comes after his words; a listener needs the name "
                       "first (\"Musk says ...\", BP-95)", sev("BP-95"))
            spk = set(reported_turns(ln["text"], cast))
            if len(spk) > REPORTED_SPEAKERS_MAX:
                _f(out, "ST-16", where, f"{len(spk)} speakers reported in one line ({', '.join(sorted(spk))}): at most "
                   f"{REPORTED_SPEAKERS_MAX}; a third enters as an action or in the next exchange (BP-96)", sev("BP-96"))
    return out


def _docudrama(out: list, segs: list, sd: list, seg_words: list) -> None:
    """Template D (the historical docudrama): narration blocks stay short (ST-17), the central scene is the longest
    scene (ST-18) and the narrator keeps a share of the words (ST-19). All three are hypotheses, REVIEW."""
    run, run_from, total_n, total = 0, None, 0, 0
    for s in segs:
        for ln in s.get("lines", []):
            w = len(ln["text"].split())
            total += w
            if ln.get("speaker"):
                run, run_from = 0, None
                continue
            total_n += w
            run_from = run_from or s["id"]
            run += w
            if run / WORDS_PER_S > NARRATION_BLOCK_MAX_S:
                _f(out, "ST-17", f"{run_from}..{s['id']}", f"the narrator talks about {run / WORDS_PER_S:.0f} s without a "
                   f"character line: give the scene back within {NARRATION_BLOCK_MAX_S:g} s (BP-104)", sev("BP-104"))
                run, run_from = 0, None
    scenes = [(sid, d, w) for (sid, d), w, s in zip(sd, seg_words, segs)
              if any(ln.get("speaker") for ln in s.get("lines", []))]
    central = [x for x in scenes if x[1] and x[1]["function"] in CENTRAL_FUNCS]
    if not central and scenes:
        _f(out, "ST-18", "segments", "no central scene: one scene with dialogue is the climax, crisis or midpoint")
    elif central:
        top = max(central, key=lambda x: x[2])
        longer = [x[0] for x in scenes if x[2] > top[2]]
        if longer:
            _f(out, "ST-18", top[0], f"the central scene is shorter than {', '.join(longer)}: it should be the longest scene, "
               "with 2-3 escalations inside")
    if total:
        share = total_n / total
        if not NARRATOR_SHARE[0] <= share <= NARRATOR_SHARE[1]:
            _f(out, "ST-19", "lines", f"the narrator has {share:.0%} of the words (aim {NARRATOR_SHARE[0]:.0%}-"
               f"{NARRATOR_SHARE[1]:.0%}, BP-105; a rivalry story may sit low, a campaign high)", sev("BP-105"))


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    doc = json.loads(Path(argv[0]).read_text(encoding="utf-8"))
    found = lint(doc)
    for f in found:
        print(f"{f['severity']:6} {f['rule']} {f['where']}: {f['detail']}")
    n_fail = sum(f["severity"] == "FAIL" for f in found)
    print(f"{n_fail} FAIL, {len(found) - n_fail} REVIEW")
    return 1 if n_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
