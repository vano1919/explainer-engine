# Publishing and analytics

## Workflow (manual; P-20)
Package built and QA-clean -> creator reviews the review bundle -> **approval #2 recorded** -> the creator uploads in
Studio (visibility and schedule are the creator's) -> the creator gives the video id -> `record` stores it and starts the
snapshot schedule. Studio settings checklist: audience "not made for kids"; altered/synthetic label only if the policy
checklist says so; chapters; sources in the description; no mid-roll ads decision recorded; end screen to the next video.

## YouTube staging (D-57)
The finished episode is uploaded unlisted (or private), never public, by one command; the creator reviews in Studio and
clicks Public there.

```powershell
python -m explainer_engine.publish thumbnail <episode>                 # price and prompt; nothing paid
python -m explainer_engine.publish thumbnail <episode> --generate --approved-by "<who, where>"   # after the creator's OK
python -m explainer_engine.publish stage <episode>                     # dry run: youtube_stage.json + checklist, no network
python -m explainer_engine.publish stage <episode> --yes --confirm "<who, where>"   # upload: long video, Shorts (thumbnail is the creator's, set in Studio)
```

Inputs: `publish.json` (publish/1 with `tags`, `youtube`, `thumbnail`, per-Short `title`; PC rules must have no FAIL), the
Shorts of `production_script.json`, the render (`render/video.mp4`, `render/shorts/SHxx.mp4`, or `--video` / `--shorts-dir`).
Sign-in (creator, 2026-10-19: no token is stored or pasted anywhere): a Google Cloud project with the YouTube Data API v3 and a
Desktop-app OAuth client whose JSON is the cloud variable `YOUTUBE_CLIENT_B64` (a client secret is not a token). The token is
obtained per upload session: Claude runs `python -m explainer_engine.publish auth-url` and gives the creator the link; the
creator signs in on a phone as the channel's account (the app may stay in Testing, the account listed as a test user) and
sends back the `http://127.0.0.1:8765/?...` address, which fails to load by design; `auth-finish '<address>'` exchanges it
for a token in the gitignored `tools/youtube/token.json` of that session only, along with the channel id, which `stage`
checks. The desktop route (`auth <client_secret.json>` on a PC) is the same flow. Quota per V-47: an episode of 1 + 10 videos uses 11 of 100 daily uploads and about 65 of 10,000 units.

## Cadence hypothesis (D-06; not competitor frequency)
One long-form every two weeks and two Shorts a week for the first cycle, from estimated hours
([COST_AND_TIME_MODEL](COST_AND_TIME_MODEL.md)), revisited after three long-forms. What competitors post (SE-26) and what
the data proves are different from what this creator can sustain; the time log decides.

## First production cycle
Prototype passes -> batch research for three topics at once -> 3 long-forms and 6-9 Shorts over about six weeks ->
Shorts on a fixed weekly rhythm -> review at the end of the cycle. Candidates below are hypotheses, not guarantees; each
needs its dossier before it is chosen.

| Topic (D-25) | Collision type / test arm | Evidence | Main uncertainty |
|---|---|---|---|
| How long would you last as a medieval peasant? | you_in_era / arm 1 | SE-37, SE-44 ("medieval peasants" +49 %) | well covered by others; needs a fresh angle |
| What could a Roman soldier's pay buy? | money_across_eras / arm 1 | SE-39 (Roman soldier 1.14M; cowboy money 253k) | conversions are uncertain: ranges, amber framing |
| A Roman engineer visits a modern city | past_meets_present / arm 2 | SE-38 | needs strong sourcing on Roman engineering to avoid caricature |
| What if dinosaurs never went extinct? | world_what_if / arm 2 | SE-40 | speculative science: amber, sources on the K-Pg event |
| How did people keep warm in a medieval castle? | how_it_worked / arm 1 | SE-39 (Runic 376k) | building-history sources vary |

## Metrics (current YouTube definitions; Shorts and long-form never mixed)
Impressions, impressions CTR, traffic source, video age, average view duration, average percentage viewed, retention curve
and the opening drop-off, returning viewers, subscriber conversion; for Shorts: viewed vs swiped away and the Shorts feed
metrics where shown. Also our own: production hours, cost, QA failures, revisions. Snapshots at 48 hours, 7 days and
28 days (P-104), each with video age and traffic context. Comparisons are like with like (same length band, age and
traffic source); correlation is not recorded as cause.

## Learning loop (what to change)
| Symptom | Likely area | First action |
|---|---|---|
| low impressions | topic, packaging, channel reach | check topic demand and the title/thumbnail pair |
| low CTR, normal retention | packaging | revise thumbnail or title (one change) |
| early drop (first 30 s) | hook | rewrite the hook spec |
| mid or late drop | structure, length, pacing | shorten or restructure |
| QA failures at release | pipeline | fix the stage, not the content |

Re-edit triggers read from Studio after publishing (the thresholds are BP-48's; the Shorts' posting spread is BP-47's, checked
by `publish/plan.py` on `publish_date`):

| Studio reading | what it says | first action |
|---|---|---|
| Intro ("still watching at 30 s") under BP-48's review line | the opening loses them | rework the first 30 s toward BP-48's target (BP-03..BP-05) |
| a Short's "chose to view" under BP-48's minimum | frame 0 and line 1 | rework the first frame and the hook line (BP-11) |
| a drop of BP-48's hook points before 3 s | the hook | rewrite the hook, not the body |
| a steeper mid-curve than the channel's others | pacing | shorten or re-cut the middle (BP-40..BP-42) |
| a drop in the last 15 % | a late payoff | move the payoff earlier or cut the tail (BP-43) |
| a Short under 30 s with average view duration under its length | no loop | end on the line that sends them back to frame 0 (BP-44) |

Change one major variable at a time; no conclusion from fewer than three comparable videos; a pattern is retained,
changed or retired only after that sample, and the specification changes through a new versioned decision (a new D- id)
while the baseline stays visible. A/B thumbnails use YouTube's own Test and Compare only after the feature is confirmed
available on the channel; otherwise controlled manual comparisons are labelled confounded.

## Scale and revise triggers
Scale cadence only when the time log shows hours per long-form at or below the target (4-6 h) for three videos in a
row. Revisit positioning (fallback in the decision log) only on the trigger stated there.
