#!/usr/bin/env python3
"""Explainer Engine v4.1 — Gate G5 Autonomous Batch Image Generator Worker (`batch_image_generator.py`).

Reads `ep_toba_74000bce_12min_g5_gemini_image_queue.json` (168 unique shots/keyframes)
and renders each 16:9 image into `02_keyframes/` using the official `google-genai` SDK.

Key Features:
1. Official `google-genai` SDK Support:
   - Primary engine: `imagen-3.0-generate-002` via `client.models.generate_images(...)` with 16:9 aspect ratio.
   - Multimodal reference fallback/option: `gemini-2.0-flash-preview-image-generation` via
     `client.models.generate_content(...)` when reference plates from `Reference_Library/` are attached.
2. Idempotent Resume / Skip Mechanism:
   - Checks if `02_keyframes/<asset_id>.png` already exists and is valid (`>= 8 KB`).
   - Maintains a live `02_keyframes/g5_generation_ledger.json` checkpoint after every single frame
     so interrupted runs resume from the exact next frame without wasting API quota.
3. Resilient Error Handling & Rate-Limit Backoff:
   - Catches HTTP 429 (`RESOURCE_EXHAUSTED`), 500/503, and network timeouts.
   - Applies exponential backoff (`10s -> 20s -> 40s -> 80s -> 120s`) before retrying,
     and logs any permanent failures without crashing the 168-frame batch run.
4. Real-Time Console Progress Telemetry:
   - Prints exact index (`[014/168]`), `asset_id`, `bucket`, elapsed time, and ETA.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from google import genai
    from google.genai import types
    from google.genai.errors import APIError
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "[ERROR] Missing official `google-genai` SDK. Install it first:\n"
        "    pip install -U google-genai pillow\n"
    ) from exc

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    Image = None  # type: ignore


DEFAULT_QUEUE_FILE = "ep_toba_74000bce_12min_g5_gemini_image_queue.json"
DEFAULT_OUTPUT_DIR = "02_keyframes"
DEFAULT_REFERENCE_DIR = "Reference_Library"
DEFAULT_IMAGEN_MODEL = "imagen-3.0-generate-002"
DEFAULT_GEMINI_IMAGE_MODEL = "gemini-2.0-flash-preview-image-generation"
MIN_VALID_IMAGE_BYTES = 8_192  # 8 KB minimum to prevent 0-byte or corrupted partial writes


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_queue(queue_path: Path) -> Dict[str, Any]:
    """Load and validate the Gate G5 JSON queue file."""
    if not queue_path.exists():
        raise FileNotFoundError(f"Queue JSON file not found: {queue_path}")
    data = json.loads(queue_path.read_text(encoding="utf-8"))
    if "queue" not in data or not isinstance(data["queue"], list):
        raise ValueError(f"Invalid G5 queue schema in {queue_path}: missing 'queue' list.")
    return data


def is_already_generated(out_file: Path) -> bool:
    """Return True if the target image file already exists and is non-corrupted."""
    if not out_file.exists() or out_file.stat().st_size < MIN_VALID_IMAGE_BYTES:
        return False
    if Image is not None:
        try:
            with Image.open(out_file) as img:
                img.verify()
            return True
        except Exception:
            return False
    return True


def save_ledger(ledger_path: Path, ledger: Dict[str, Any]) -> None:
    """Atomically persist the batch progress ledger to disk."""
    tmp_path = ledger_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp_path.replace(ledger_path)


def generate_single_image_imagen3(
    client: genai.Client,
    prompt: str,
    aspect_ratio: str = "16:9",
    model_name: str = DEFAULT_IMAGEN_MODEL,
) -> bytes:
    """Generate a single 16:9 image using `imagen-3.0-generate-002` via `google-genai`."""
    result = client.models.generate_images(
        model=model_name,
        prompt=prompt,
        config=types.GenerateImagesConfig(
            number_of_images=1,
            output_mime_type="image/png",
            aspect_ratio=aspect_ratio,
            person_generation="ALLOW_ADULT",
            safety_filter_level="BLOCK_ONLY_HIGH",
        ),
    )
    if not result.generated_images:
        raise RuntimeError("Imagen API returned an empty `generated_images` list (check safety filter or prompt).")
    img_bytes = result.generated_images[0].image.image_bytes
    if not img_bytes:
        raise RuntimeError("Imagen API returned empty `image_bytes`.")
    return img_bytes


def generate_single_image_gemini_multimodal(
    client: genai.Client,
    prompt: str,
    reference_paths: List[Path],
    model_name: str = DEFAULT_GEMINI_IMAGE_MODEL,
) -> bytes:
    """Generate an image conditioned on Reference Library anchor plates via Gemini multimodal image generation."""
    contents: List[Any] = []
    if Image is not None:
        for ref_p in reference_paths:
            if ref_p.exists():
                contents.append(Image.open(ref_p))
    contents.append(f"Generate a 16:9 widescreen cinematic frame matching the style reference: {prompt}")

    response = client.models.generate_content(
        model=model_name,
        contents=contents,
        config=types.GenerateContentConfig(
            response_modalities=["TEXT", "IMAGE"],
        ),
    )
    for candidate in response.candidates or []:
        for part in (candidate.content.parts if candidate.content else []):
            if part.inline_data and part.inline_data.data:
                return part.inline_data.data
    raise RuntimeError("Gemini multimodal image generation returned no inline image data.")


def generate_with_retry(
    client: genai.Client,
    item: Dict[str, Any],
    ref_dir: Path,
    model_name: str,
    use_multimodal_refs: bool,
    max_retries: int = 5,
    base_backoff_sec: float = 10.0,
) -> bytes:
    """Execute image generation with exponential backoff on rate limits (429) or transient server errors."""
    prompt = str(item.get("query") or "").strip()
    aspect_ratio = str(item.get("aspect_ratio") or "16:9")
    ref_names = item.get("image_references") or []
    ref_paths = [ref_dir / r for r in ref_names if (ref_dir / r).exists()]

    for attempt in range(1, max_retries + 1):
        try:
            if use_multimodal_refs and ref_paths:
                return generate_single_image_gemini_multimodal(
                    client=client,
                    prompt=prompt,
                    reference_paths=ref_paths,
                    model_name=DEFAULT_GEMINI_IMAGE_MODEL,
                )
            return generate_single_image_imagen3(
                client=client,
                prompt=prompt,
                aspect_ratio=aspect_ratio,
                model_name=model_name,
            )
        except APIError as api_err:
            status_code = getattr(api_err, "code", None)
            err_msg = str(api_err)
            is_rate_limit = status_code == 429 or "429" in err_msg or "RESOURCE_EXHAUSTED" in err_msg.upper()
            wait_sec = base_backoff_sec * (2 ** (attempt - 1)) if is_rate_limit else base_backoff_sec * attempt
            print(
                f"    [WARN] APIError (code={status_code}) on attempt {attempt}/{max_retries}: {err_msg[:120]}",
                flush=True,
            )
            if attempt == max_retries:
                raise
            print(f"    [SLEEP] Waiting {wait_sec:.1f}s before retry...", flush=True)
            time.sleep(wait_sec)
        except Exception as err:
            wait_sec = base_backoff_sec * attempt
            print(
                f"    [WARN] Unexpected error on attempt {attempt}/{max_retries}: {err}",
                flush=True,
            )
            if attempt == max_retries:
                raise
            print(f"    [SLEEP] Waiting {wait_sec:.1f}s before retry...", flush=True)
            time.sleep(wait_sec)

    raise RuntimeError(f"Exhausted all {max_retries} retries for {item.get('asset_id')}.")


def run_batch(
    queue_path: Path,
    output_dir: Path,
    ref_dir: Path,
    api_key: Optional[str] = None,
    model_name: str = DEFAULT_IMAGEN_MODEL,
    use_multimodal_refs: bool = False,
    delay_between_requests_sec: float = 4.5,
    max_retries: int = 5,
    limit: Optional[int] = None,
    segment_filter: Optional[str] = None,
) -> int:
    """Main worker loop: processes all 168 items with resume/skip, rate-limit pacing, and checkpointing."""
    resolved_key = api_key or os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not resolved_key:
        print(
            "[ERROR] GEMINI_API_KEY environment variable is not set.\n"
            "Set it via: export GEMINI_API_KEY='your_api_key_here'",
            file=sys.stderr,
        )
        return 1

    client = genai.Client(api_key=resolved_key)
    queue_doc = load_queue(queue_path)
    items: List[Dict[str, Any]] = queue_doc["queue"]

    if segment_filter:
        items = [x for x in items if x.get("segment_id") == segment_filter]

    total = len(items)
    output_dir.mkdir(parents=True, exist_ok=True)
    for bucket_sub in ("10pct_maps_and_diagrams", "30pct_photo_collage", "60pct_video_keyframes"):
        (output_dir / bucket_sub).mkdir(parents=True, exist_ok=True)

    ledger_path = output_dir / "g5_generation_ledger.json"
    ledger: Dict[str, Any] = {
        "episode_id": queue_doc.get("episode_id", "ep_toba_74000bce_12min"),
        "model": model_name,
        "started_at_utc": _utc_now(),
        "total_queued": total,
        "completed_count": 0,
        "skipped_existing_count": 0,
        "failed_count": 0,
        "completed_assets": {},
        "failed_assets": {},
    }
    if ledger_path.exists():
        try:
            old_ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
            ledger["completed_assets"] = old_ledger.get("completed_assets", {})
        except Exception:
            pass

    print("=" * 78)
    print(f"EXPLAINER ENGINE v4.1 — GATE G5 BATCH IMAGE WORKER")
    print(f"Episode ID   : {queue_doc.get('episode_id')}")
    print(f"Queue File   : {queue_path}")
    print(f"Output Dir   : {output_dir.resolve()}")
    print(f"Model        : {model_name} (multimodal_refs={use_multimodal_refs})")
    print(f"Total Frames : {total} (segment_filter={segment_filter or 'ALL'})")
    print("=" * 78, flush=True)

    rendered_this_run = 0
    start_ts = time.time()

    for idx, item in enumerate(items, start=1):
        asset_id = str(item.get("asset_id") or f"frame_{idx:03d}")
        shot_id = str(item.get("shot_id") or "?")
        seg_id = str(item.get("segment_id") or "?")
        bucket = str(item.get("bucket") or "60pct_video_keyframes")
        frame_role = str(item.get("frame_role") or "start_frame")

        # Save both in the flat `02_keyframes/<asset_id>.png` path and bucket subfolder link
        flat_out_path = output_dir / f"{asset_id}.png"
        bucket_out_path = output_dir / bucket / f"{asset_id}.png"

        if is_already_generated(flat_out_path):
            ledger["skipped_existing_count"] += 1
            ledger["completed_assets"][asset_id] = str(flat_out_path)
            print(
                f"[{idx:03d}/{total:03d}] [SKIP] {asset_id} ({seg_id} | {bucket}) already exists ({flat_out_path.stat().st_size // 1024} KB).",
                flush=True,
            )
            continue

        if limit is not None and rendered_this_run >= limit:
            print(f"\n[INFO] Reached user-specified `--limit {limit}`. Stopping cleanly.", flush=True)
            break

        print(
            f"[{idx:03d}/{total:03d}] [GEN ] {asset_id} | shot={shot_id} | role={frame_role} | bucket={bucket} ...",
            flush=True,
        )
        t0 = time.time()
        try:
            img_bytes = generate_with_retry(
                client=client,
                item=item,
                ref_dir=ref_dir,
                model_name=model_name,
                use_multimodal_refs=use_multimodal_refs,
                max_retries=max_retries,
            )
            flat_out_path.write_bytes(img_bytes)
            bucket_out_path.write_bytes(img_bytes)

            dt = time.time() - t0
            rendered_this_run += 1
            ledger["completed_count"] += 1
            ledger["completed_assets"][asset_id] = {
                "path": str(flat_out_path),
                "bucket_path": str(bucket_out_path),
                "bytes": len(img_bytes),
                "generated_at_utc": _utc_now(),
                "render_sec": round(dt, 2),
            }
            save_ledger(ledger_path, ledger)
            print(
                f"    [OK  ] Saved {flat_out_path.name} ({len(img_bytes) // 1024} KB in {dt:.1f}s)",
                flush=True,
            )

            if idx < total:
                time.sleep(delay_between_requests_sec)

        except Exception as exc:
            ledger["failed_count"] += 1
            ledger["failed_assets"][asset_id] = {
                "shot_id": shot_id,
                "error": str(exc),
                "failed_at_utc": _utc_now(),
            }
            save_ledger(ledger_path, ledger)
            print(f"    [FAIL] Could not generate {asset_id}: {exc}", file=sys.stderr, flush=True)

    total_elapsed = time.time() - start_ts
    done_total = len(ledger["completed_assets"])
    print("\n" + "=" * 78)
    print(f"GATE G5 BATCH SUMMARY")
    print(f"Completed Total : {done_total}/{total} (New: {ledger['completed_count']}, Skipped existing: {ledger['skipped_existing_count']})")
    print(f"Failed Count    : {ledger['failed_count']}")
    print(f"Elapsed Time    : {total_elapsed / 60:.1f} minutes")
    print(f"Progress Ledger : {ledger_path}")
    print("=" * 78, flush=True)

    return 0 if ledger["failed_count"] == 0 else 2


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gate G5 Autonomous Gemini/Imagen Batch Image Generator (Explainer Engine v4.1)."
    )
    parser.add_argument(
        "--queue",
        type=Path,
        default=Path(DEFAULT_QUEUE_FILE),
        help=f"Path to Gate G5 queue JSON (default: {DEFAULT_QUEUE_FILE})",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(DEFAULT_OUTPUT_DIR),
        help=f"Output folder for generated PNG keyframes (default: {DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "--refs",
        type=Path,
        default=Path(DEFAULT_REFERENCE_DIR),
        help=f"Path to Reference_Library folder (default: {DEFAULT_REFERENCE_DIR})",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=DEFAULT_IMAGEN_MODEL,
        help=f"Imagen model ID (default: {DEFAULT_IMAGEN_MODEL})",
    )
    parser.add_argument(
        "--use-multimodal-refs",
        action="store_true",
        help="Use Gemini multimodal image generation conditioned on Reference_Library anchor images.",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=4.5,
        help="Delay in seconds between API requests to respect RPM quota (default: 4.5s).",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=5,
        help="Max retries per image on 429/5xx errors (default: 5).",
    )
    parser.add_argument(
        "--segment",
        type=str,
        default=None,
        help="Optional segment filter (e.g. S01, S02) to render one segment at a time.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional maximum number of new images to generate in this run.",
    )
    return parser.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    raise SystemExit(
        run_batch(
            queue_path=args.queue,
            output_dir=args.out,
            ref_dir=args.refs,
            model_name=args.model,
            use_multimodal_refs=args.use_multimodal_refs,
            delay_between_requests_sec=args.delay,
            max_retries=args.retries,
            limit=args.limit,
            segment_filter=args.segment,
        )
    )
