#!/usr/bin/env python3
"""Explainer Engine v4.2 — Gates G6 & G7 Unified Batch Worker (`batch_video_and_animation_worker.py`, D-130).

Automatically loads all API tokens from `env_config_v4.env` / `.env` on Google Drive and executes:
1. Gate G6 Hybrid Voice & Speech Spine:
   - Narrator (`narrator_main`): ElevenLabs `'Odom - Deep, Resonant, Dramatic'` (`CcSJ2r3qw0XU9gJpEPyk`,
     model `eleven_v4`, with fallback `JBFqnCBsd6RMkjVDRZzb`).
   - Recurring Characters across nearby scenes: ElevenLabs locked character voices.
   - One-Scene or Widely-Spaced Characters (`segment_gap >= 3`): Routed to `WAN_S2V_CHARACTER_SPEECH` (`VC-T1-04`).
2. Gate G7 Layer 1 (10% Info-Graphics, Maps, Troop Movements, Diagrams & Numbers):
   - Rendered deterministically in Python (`PYTHON_INFO_GRAPHICS_RENDER`) in clean YouTube-docudrama style.
3. Gate G7 Layer 2 (30% Collages + Simple & Test-Medium 60% Video Shots):
   - Rendered via Google Video API (`gemini-omni-1.2-flash`) in unified cinematic chiaroscuro style.
4. Gate G7 Layer 3 (Heavy 60% Video Shots — `WAN_FLF2V`, `WAN-CHAIN-MINUS-5` `frame[-5]`, `WAN_CONTROL`, `WAN_S2V`):
   - Rendered via Wan 2.1 / 2.2 on Modal / FAL GPU.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict

from explainer_engine.core.env_loader import (
    FALLBACK_NARRATOR_VOICE_ID,
    LOCKED_NARRATOR_VOICE_ID,
    LOCKED_NARRATOR_VOICE_NAME,
    load_project_env,
)
from explainer_engine.core.model_lifecycle_guard import ACTIVE_CANONICAL_MODELS, assert_active_model
from explainer_engine.aivideo.wan_optimizer import (
    analyze_character_appearance_cadence,
    plan_parallel_g7_threads,
)
from explainer_engine.orchestration.cohesive_film_engine import build_cohesive_film_edl


def build_g6_g7_execution_manifest(
    script_doc: Dict[str, Any],
    google_test_medium_complexity: bool = True,
) -> Dict[str, Any]:
    """Build the complete Gate G6 + Gate G7 execution plan for an approved `production_script.json`."""
    env_status = load_project_env()
    g7_plan = plan_parallel_g7_threads(script_doc, google_test_medium_complexity=google_test_medium_complexity)
    edl = build_cohesive_film_edl(script_doc)
    audio_lines = script_doc.get("audio_lines", [])
    cadence = analyze_character_appearance_cadence(audio_lines)
    tts_model = assert_active_model(ACTIVE_CANONICAL_MODELS["g6_narrator_tts"])

    elevenlabs_lines = []
    wan_speech_lines = []
    for ln in audio_lines:
        spk_type = ln.get("speaker_type")
        spk_id = str(ln.get("speaker_id") or "")
        if spk_type == "narrator":
            elevenlabs_lines.append({
                "line_id": ln["line_id"],
                "segment_id": ln["segment_id"],
                "speaker_id": spk_id,
                "voice_id": LOCKED_NARRATOR_VOICE_ID,
                "voice_name": LOCKED_NARRATOR_VOICE_NAME,
                "fallback_voice_id": FALLBACK_NARRATOR_VOICE_ID,
                "duration_sec": ln["estimated_duration_seconds"],
                "model_id": tts_model,
                "engine": "ELEVENLABS_TTS_V4",
            })
        elif spk_type == "character":
            c_info = cadence.get(spk_id, {})
            if c_info.get("use_wan_speech"):
                wan_speech_lines.append({
                    "line_id": ln["line_id"],
                    "segment_id": ln["segment_id"],
                    "speaker_id": spk_id,
                    "duration_sec": ln["estimated_duration_seconds"],
                    "engine": "WAN_S2V_CHARACTER_SPEECH",
                    "reason": c_info.get("reason"),
                })
            else:
                elevenlabs_lines.append({
                    "line_id": ln["line_id"],
                    "segment_id": ln["segment_id"],
                    "speaker_id": spk_id,
                    "voice_id": f"elevenlabs_profile_{spk_id}",
                    "duration_sec": ln["estimated_duration_seconds"],
                    "model_id": tts_model,
                    "engine": "ELEVENLABS_TTS_V4",
                })

    return {
        "schema": "g6_g7_unified_execution_manifest/1",
        "episode_id": script_doc.get("episode_id", "unknown"),
        "env_credentials_ready": env_status,
        "gate_g6_voice_and_speech_spine": {
            "narrator_voice": {
                "voice_id": LOCKED_NARRATOR_VOICE_ID,
                "voice_name": LOCKED_NARRATOR_VOICE_NAME,
                "model_id": tts_model,
                "library_notice_period_days": 730,
                "usable_immediately": True,
                "fallback_voice_id": FALLBACK_NARRATOR_VOICE_ID,
            },
            "character_cadence_routing": cadence,
            "elevenlabs_tts_lines_count": len(elevenlabs_lines),
            "wan_native_speech_lines_count": len(wan_speech_lines),
            "elevenlabs_lines": elevenlabs_lines,
            "wan_speech_lines": wan_speech_lines,
        },
        "gate_g7_visual_and_video_routing": {
            "thread_a_batch_animated_stills_and_maps": g7_plan["thread_a_10pct_and_30pct"],
            "thread_b_hybrid_gemini_and_wan_video": {
                "gemini_video_simple_count": g7_plan["thread_b_60pct_wan_modal"]["gemini_video_simple_count"],
                "wan_2_1_complex_planned_count": g7_plan["thread_b_60pct_wan_modal"]["wan_complex_planned_count"],
                "gemini_video_simple_jobs": g7_plan["thread_b_60pct_wan_modal"]["gemini_video_simple_jobs"],
                "wan_2_1_complex_planned_jobs": g7_plan["thread_b_60pct_wan_modal"]["wan_complex_planned_jobs"],
            },
        },
        "gate_g8_cohesive_edl_summary": {
            "total_duration_sec": edl["total_duration_sec"],
            "total_shots": edl["total_shots"],
            "j_l_cut_audio_bridges_count": edl["j_l_cut_audio_bridges_count"],
            "frame_minus_5_seamless_chains_count": edl["frame_minus_5_seamless_chains_count"],
        },
    }


if __name__ == "__main__":
    script_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("jobs/ep_waterloo_12min/production_script.json")
    doc = json.loads(script_path.read_text(encoding="utf-8"))
    manifest = build_g6_g7_execution_manifest(doc)
    out_p = script_path.with_name(f"{doc.get('episode_id', 'episode')}_g6_g7_manifest.json")
    out_p.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote G6/G7 manifest to {out_p}")
