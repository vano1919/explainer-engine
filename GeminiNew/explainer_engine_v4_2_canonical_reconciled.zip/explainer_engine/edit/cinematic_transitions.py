"""First-Class Continuity-Aware Cinematic Transition System (`cinematic_transitions.py`, v4.2).

Extends `explainer_engine.production.continuity` and `explainer_engine.production.chunked_edit`
to make transitions between shots intentional, story-driven, and visually cohesive:
- Supported Transition Families (`TRANSITION_TYPES`):
  1. `map_to_location_zoom_through`: Camera zooms into a specific point (`zoom_target_xy`) on a 10% tactical map,
     passes through an atmospheric cloud/vignette veil, and emerges seamlessly into the destination location shot.
  2. `infographic_number_to_scene_morph`: Transitions from a 10% data/counter/timeline graphic into the physical
     historical scene with focal-point cross-dissolve and chiaroscuro rim-light bloom.
  3. `match_cut_shape_and_focus`: Aligns dominant focal geometry and luminance contour between Shot A and Shot B.
  4. `motion_matched_pan_whip`: Continues camera directional movement across the cut with directional motion blur.
  5. `foreground_object_wipe`: A dark chiaroscuro foreground silhouette/column sweeps across the frame to reveal Shot B.
  6. `atmospheric_smoke_ash_wipe`: Volumetric smoke, fog, or volcanic ash billows across the cut to reveal Shot B.
  7. `cross_dissolve_8f`: Smooth 8-to-12 frame chiaroscuro dissolve across temporal or segment shifts.
  8. `hard_cut_with_jl_bridge`: Crisp editorial cut paired with J-cut/L-cut audio prelap/postlap continuity.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Tuple

import numpy as np
from PIL import Image, ImageFilter

TRANSITION_TYPES: Tuple[str, ...] = (
    "map_to_location_zoom_through",
    "infographic_number_to_scene_morph",
    "match_cut_shape_and_focus",
    "motion_matched_pan_whip",
    "foreground_object_wipe",
    "atmospheric_smoke_ash_wipe",
    "cross_dissolve_8f",
    "hard_cut_with_jl_bridge",
)

CAMERA_MOVE_VECTORS: Dict[str, Tuple[float, float, float]] = {
    # (dx, dy, dz) normalized direction vectors
    "static": (0.0, 0.0, 0.0),
    "slow_push_in": (0.0, 0.0, 1.0),
    "push_in": (0.0, 0.0, 1.0),
    "parallax_dolly": (0.0, 0.0, 0.8),
    "slow_pull_back": (0.0, 0.0, -1.0),
    "pull_back": (0.0, 0.0, -1.0),
    "pan_left": (-1.0, 0.0, 0.0),
    "pan_right": (1.0, 0.0, 0.0),
    "parallax_orbital": (0.7, 0.0, 0.4),
    "tracking_shot": (0.9, 0.0, 0.3),
    "tilt_up": (0.0, -1.0, 0.0),
    "tilt_down": (0.0, 1.0, 0.0),
}


def compute_visual_continuity_alignment(
    shot_a: Dict[str, Any],
    shot_b: Dict[str, Any],
) -> Dict[str, Any]:
    """Analyze visual continuity across Shot A -> Shot B across 5 dimensions:
    1. Screen position of key elements (`focal_xy`)
    2. Camera direction & motion vector (`camera_move`, `horizontal_azimuth_deg`)
    3. Dominant composition shapes (`shot_size`, `foreground`/`midground`)
    4. Lighting continuity (`lighting_and_time`)
    5. Geographic & narrative connection (`location_id`, `segment_id`, `visual_type`)
    """
    cam_a = shot_a.get("camera_spec") or {}
    cam_b = shot_b.get("camera_spec") or {}
    move_a = str(cam_a.get("camera_move") or "static")
    move_b = str(cam_b.get("camera_move") or "static")
    vec_a = CAMERA_MOVE_VECTORS.get(move_a, (0.0, 0.0, 0.0))
    vec_b = CAMERA_MOVE_VECTORS.get(move_b, (0.0, 0.0, 0.0))

    dot_motion = vec_a[0] * vec_b[0] + vec_a[1] * vec_b[1] + vec_a[2] * vec_b[2]
    motion_aligned = dot_motion > 0.25

    focal_a = shot_a.get("zoom_target_xy") or shot_a.get("focal_xy") or [0.5, 0.5]
    focal_b = shot_b.get("focal_xy") or [0.5, 0.5]
    focal_dist = math.hypot(float(focal_a[0]) - float(focal_b[0]), float(focal_a[1]) - float(focal_b[1]))

    same_location = shot_a.get("location_id") == shot_b.get("location_id")
    same_segment = shot_a.get("segment_id") == shot_b.get("segment_id")

    light_a = str(shot_a.get("lighting_and_time") or "").lower()
    light_b = str(shot_b.get("lighting_and_time") or "").lower()
    shared_light_tokens = set(light_a.split()) & set(light_b.split())
    lighting_coherent = len(shared_light_tokens) >= 1 or same_location

    return {
        "from_shot_id": shot_a.get("shot_id"),
        "to_shot_id": shot_b.get("shot_id"),
        "focal_xy_from": [round(float(focal_a[0]), 3), round(float(focal_a[1]), 3)],
        "focal_xy_to": [round(float(focal_b[0]), 3), round(float(focal_b[1]), 3)],
        "focal_distance_norm": round(focal_dist, 4),
        "camera_move_from": move_a,
        "camera_move_to": move_b,
        "motion_vector_dot": round(dot_motion, 3),
        "motion_direction_aligned": motion_aligned,
        "same_location": same_location,
        "same_segment": same_segment,
        "lighting_coherent": lighting_coherent,
    }


def select_optimal_cinematic_transition(
    shot_a: Dict[str, Any],
    shot_b: Dict[str, Any],
    fps: int = 24,
) -> Dict[str, Any]:
    """Select the optimal cinematic transition and audio bridge between Shot A and Shot B."""
    continuity = compute_visual_continuity_alignment(shot_a, shot_b)
    vtype_a = str(shot_a.get("visual_type") or "")
    vtype_b = str(shot_b.get("visual_type") or "")
    gmode_a = str(shot_a.get("generation_mode") or "")
    gmode_b = str(shot_b.get("generation_mode") or "")

    is_a_infographic = vtype_a == "map_visualization" or gmode_a in ("TACTILE_MAP", "MAP_25D")
    is_b_infographic = vtype_b == "map_visualization" or gmode_b in ("TACTILE_MAP", "MAP_25D")

    text_ab = " ".join([
        str(shot_a.get("narrative_purpose") or ""),
        str(shot_a.get("action_end_state") or ""),
        str(shot_b.get("narrative_purpose") or ""),
        str(shot_b.get("action_start_state") or ""),
    ]).lower()

    # 1. Map / Infographic -> Physical Location Scene Transition
    if is_a_infographic and not is_b_infographic:
        subtype_a = str(shot_a.get("infographic_subtype") or "")
        if "counter" in subtype_a or "diagram" in subtype_a or "timeline" in subtype_a or any(
            k in str(shot_a.get("narrative_purpose") or "").lower() for k in ("counter", "population", "timeline", "diagram")
        ):
            t_type = "infographic_number_to_scene_morph"
            dur_frames = 14
            audio_prelap_s = 0.45
        else:
            t_type = "map_to_location_zoom_through"
            dur_frames = 16
            audio_prelap_s = 0.50
    # 2. Physical Scene -> Map / Infographic Transition
    elif not is_a_infographic and is_b_infographic:
        t_type = "match_cut_shape_and_focus"
        dur_frames = 12
        audio_prelap_s = 0.35
    # 3. Smoke / Ash / Fog Environmental Transition
    elif any(k in text_ab for k in ("ash", "smoke", "eruption", "fog", "cloud", "cannon", "pyroclastic")):
        t_type = "atmospheric_smoke_ash_wipe"
        dur_frames = 12
        audio_prelap_s = 0.40
    # 4. Aligned directional camera movement (pan/tracking/orbital)
    elif continuity["motion_direction_aligned"] and continuity["camera_move_from"] in (
        "pan_left", "pan_right", "tracking_shot", "parallax_orbital"
    ):
        t_type = "motion_matched_pan_whip"
        dur_frames = 10
        audio_prelap_s = 0.25
    # 5. Foreground silhouette / column / battle-line wipe across different locations
    elif not continuity["same_location"] and continuity["same_segment"]:
        t_type = "foreground_object_wipe"
        dur_frames = 12
        audio_prelap_s = 0.35
    # 6. Segment change or temporal leap
    elif not continuity["same_segment"]:
        t_type = "cross_dissolve_8f"
        dur_frames = 12
        audio_prelap_s = 0.45
    # 7. Close focal alignment inside same scene
    elif continuity["focal_distance_norm"] <= 0.15 and not continuity["same_location"]:
        t_type = "match_cut_shape_and_focus"
        dur_frames = 10
        audio_prelap_s = 0.30
    else:
        t_type = "hard_cut_with_jl_bridge"
        dur_frames = 0
        audio_prelap_s = 0.30

    return {
        "from_shot_id": shot_a.get("shot_id"),
        "to_shot_id": shot_b.get("shot_id"),
        "transition_type": t_type,
        "transition_frames": dur_frames,
        "transition_duration_sec": round(dur_frames / max(fps, 1), 4),
        "audio_j_cut_prelap_sec": audio_prelap_s,
        "audio_l_cut_postlap_sec": round(audio_prelap_s * 0.85, 3),
        "zoom_target_xy": continuity["focal_xy_from"],
        "continuity": continuity,
    }


def plan_episode_cinematic_transitions(
    script_doc: Dict[str, Any],
    fps: int = 24,
) -> List[Dict[str, Any]]:
    """Build the complete shot-to-shot cinematic transition plan for an episode."""
    shots = script_doc.get("shots", [])
    plans: List[Dict[str, Any]] = []
    for a, b in zip(shots, shots[1:]):
        plans.append(select_optimal_cinematic_transition(a, b, fps=fps))
    return plans


def render_transition_frame_pair(
    frame_a: Image.Image,
    frame_b: Image.Image,
    transition_type: str,
    progress_u: float,
    zoom_target_xy: Sequence[float] = (0.58, 0.48),
    motion_direction: str = "right",
) -> Image.Image:
    """Render an intermediate transition frame (`0.0 <= progress_u <= 1.0`) between `frame_a` and `frame_b`."""
    u = float(min(1.0, max(0.0, progress_u)))
    ease_u = u * u * (3.0 - 2.0 * u)
    w, h = frame_a.size
    if frame_b.size != (w, h):
        frame_b = frame_b.resize((w, h), Image.BICUBIC)

    if transition_type == "map_to_location_zoom_through":
        # Zoom deep into zoom_target_xy on frame_a while scaling frame_b down from wide zoom to 1.0x
        tx, ty = float(zoom_target_xy[0]) * w, float(zoom_target_xy[1]) * h
        z_a = 1.0 + 2.4 * (ease_u ** 1.6)
        cw_a, ch_a = w / z_a, h / z_a
        x0_a = max(0.0, min(w - cw_a, tx - cw_a * float(zoom_target_xy[0])))
        y0_a = max(0.0, min(h - ch_a, ty - ch_a * float(zoom_target_xy[1])))
        zoomed_a = frame_a.resize((w, h), Image.BICUBIC, box=(x0_a, y0_a, x0_a + cw_a, y0_a + ch_a))
        if ease_u > 0.25:
            zoomed_a = zoomed_a.filter(ImageFilter.GaussianBlur(radius=float(8.0 * ease_u)))

        z_b = 1.35 - 0.35 * ease_u
        cw_b, ch_b = w / z_b, h / z_b
        x0_b = (w - cw_b) / 2.0
        y0_b = (h - ch_b) / 2.0
        zoomed_b = frame_b.resize((w, h), Image.BICUBIC, box=(x0_b, y0_b, x0_b + cw_b, y0_b + ch_b))

        arr_a = np.asarray(zoomed_a, dtype=np.float32)
        arr_b = np.asarray(zoomed_b, dtype=np.float32)
        # Atmospheric cloud veil peak at u=0.5
        cloud_veil = math.sin(math.pi * ease_u) ** 2 * 0.28
        veil_color = np.array([210.0, 175.0, 120.0], dtype=np.float32)
        mixed = arr_a * (1.0 - ease_u) + arr_b * ease_u
        mixed = mixed * (1.0 - cloud_veil) + veil_color[None, None, :] * cloud_veil
        return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), mode="RGB")

    if transition_type in ("infographic_number_to_scene_morph", "match_cut_shape_and_focus"):
        arr_a = np.asarray(frame_a, dtype=np.float32)
        arr_b = np.asarray(frame_b, dtype=np.float32)
        # Warm chiaroscuro bloom at midpoint to bind graphic highlights to scene rim-lights
        bloom = math.sin(math.pi * ease_u) * 0.16
        mixed = arr_a * (1.0 - ease_u) + arr_b * ease_u
        mixed[:, :, 0] += 255.0 * bloom * 0.9
        mixed[:, :, 1] += 255.0 * bloom * 0.65
        mixed[:, :, 2] += 255.0 * bloom * 0.25
        return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), mode="RGB")

    if transition_type == "motion_matched_pan_whip":
        shift_px = int(round(ease_u * w))
        arr_a = np.asarray(frame_a, dtype=np.float32)
        arr_b = np.asarray(frame_b, dtype=np.float32)
        canvas = np.zeros_like(arr_a)
        if motion_direction != "left":
            if shift_px < w:
                canvas[:, : w - shift_px] = arr_a[:, shift_px:]
            if shift_px > 0:
                canvas[:, w - shift_px :] = arr_b[:, :shift_px]
        else:
            if shift_px < w:
                canvas[:, shift_px:] = arr_a[:, : w - shift_px]
            if shift_px > 0:
                canvas[:, :shift_px] = arr_b[:, w - shift_px :]
        out_im = Image.fromarray(np.clip(canvas, 0, 255).astype(np.uint8), mode="RGB")
        blur_r = 6.0 * math.sin(math.pi * ease_u)
        return out_im.filter(ImageFilter.BoxBlur(blur_r)) if blur_r >= 1.0 else out_im

    if transition_type == "foreground_object_wipe":
        arr_a = np.asarray(frame_a, dtype=np.float32)
        arr_b = np.asarray(frame_b, dtype=np.float32)
        xx = np.linspace(0.0, 1.0, w, dtype=np.float32)[None, :]
        wipe_pos = -0.15 + 1.30 * ease_u
        band_half = 0.09
        # Mask: 0 before pillar (Shot B revealed), 1 after pillar (Shot A still visible)
        reveal_b = np.clip((wipe_pos - xx + band_half) / max(2.0 * band_half, 1e-4), 0.0, 1.0)
        pillar_dark = np.exp(-(((xx - wipe_pos) / (band_half * 0.65)) ** 2))
        mixed = arr_a * (1.0 - reveal_b[:, :, None]) + arr_b * reveal_b[:, :, None]
        mixed = mixed * (1.0 - 0.88 * pillar_dark[:, :, None]) + np.array([10.0, 12.0, 16.0])[None, None, :] * (0.88 * pillar_dark[:, :, None])
        return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), mode="RGB")

    if transition_type == "atmospheric_smoke_ash_wipe":
        arr_a = np.asarray(frame_a, dtype=np.float32)
        arr_b = np.asarray(frame_b, dtype=np.float32)
        yy = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None]
        xx = np.linspace(0.0, 1.0, w, dtype=np.float32)[None, :]
        turbulence = 0.08 * np.sin(2.0 * math.pi * (xx * 2.5 + yy * 1.5))
        mask_b = np.clip((ease_u * 1.35 - (xx * 0.7 + yy * 0.3) + turbulence) / 0.35, 0.0, 1.0)
        smoke_front = np.exp(-(((mask_b - 0.5) / 0.24) ** 2)) * 0.42
        smoke_col = np.array([92.0, 84.0, 78.0], dtype=np.float32)
        mixed = arr_a * (1.0 - mask_b[:, :, None]) + arr_b * mask_b[:, :, None]
        mixed = mixed * (1.0 - smoke_front[:, :, None]) + smoke_col[None, None, :] * smoke_front[:, :, None]
        return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), mode="RGB")

    # Default cross_dissolve_8f or fallback
    arr_a = np.asarray(frame_a, dtype=np.float32)
    arr_b = np.asarray(frame_b, dtype=np.float32)
    mixed = arr_a * (1.0 - ease_u) + arr_b * ease_u
    return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), mode="RGB")
