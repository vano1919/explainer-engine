#!/usr/bin/env python3
"""Explainer Engine v4.2 — Gate G5 Autonomous Batch Image Generator Worker (`batch_image_generator.py`, D-130).

Reads `ep_toba_74000bce_12min_g5_gemini_image_queue.json` (168 unique shots/keyframes)
and renders each 16:9 image into `02_keyframes/` using active Google Gemini Image models
(`gemini-3-pro-image`, `gemini-nano-banana-2.1`, `gemini-3.1-flash-image`), while
blocking retired endpoints (`imagen-3.0-generate-002`, `gemini-2.0-flash-preview-image-generation`,
`gemini-3-pro-image-preview`) via `model_lifecycle_guard.assert_active_model()`.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from explainer_engine.core.env_loader import load_project_env, redact_secrets_from_text
from explainer_engine.core.model_lifecycle_guard import (
    ACTIVE_CANONICAL_MODELS,
    assert_active_model,
    resolve_or_migrate_model,
)

try:
    from PIL import Image
except ImportError:  # pragma: no cover
    Image = None  # type: ignore


DEFAULT_QUEUE_FILE = "ep_toba_74000bce_12min_g5_gemini_image_queue.json"
DEFAULT_OUTPUT_DIR = "02_keyframes"
DEFAULT_ANIMATED_STILLS_DIR = "03_animated_stills"
DEFAULT_REFERENCE_DIR = "Reference_Library"
DEFAULT_PRIMARY_IMAGE_MODEL = ACTIVE_CANONICAL_MODELS["g5_keyframe_primary"]   # gemini-3-pro-image
DEFAULT_BANANA_IMAGE_MODEL = ACTIVE_CANONICAL_MODELS["g5_keyframe_banana"]     # gemini-nano-banana-2.1
DEFAULT_FAST_IMAGE_MODEL = ACTIVE_CANONICAL_MODELS["g5_keyframe_fast"]         # gemini-3.1-flash-image
MIN_VALID_IMAGE_BYTES = 8_192  # 8 KB minimum to prevent 0-byte or corrupted partial writes


def animate_photo_to_24fps_mp4(
    image_path: Path,
    out_mp4_path: Path,
    duration_sec: float = 4.5,
    preset: str = "dolly_in",
    fps: int = 24,
) -> bool:
    """Convert a 30% COLLAGE_STILL PNG into a 24fps animated MP4 clip (local fallback helper)."""
    import subprocess as _sp
    frames = max(24, int(round(duration_sec * fps)))
    out_mp4_path.parent.mkdir(parents=True, exist_ok=True)
    if preset == "dolly_out":
        zp = f"zoompan=z='if(eq(on,1),1.14,max(1.0,zoom-0.0012))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s=1920x1080:fps={fps}"
    elif preset == "pan_slide":
        zp = f"zoompan=z='1.10':x='(iw-iw/zoom)*(on/{frames})':y='ih/2-(ih/zoom/2)':d={frames}:s=1920x1080:fps={fps}"
    else:
        zp = f"zoompan=z='min(zoom+0.0012,1.15)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s=1920x1080:fps={fps}"
    vf_chain = f"scale=2240:1260,{zp},noise=alls=6:allf=t+u,format=yuv420p"
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-loop", "1", "-i", str(image_path),
        "-vf", vf_chain,
        "-t", f"{duration_sec:.2f}",
        "-c:v", "libx264", "-preset", "veryfast", "-b:v", "6500k",
        str(out_mp4_path),
    ]
    res = _sp.run(cmd, capture_output=True, text=True)
    return res.returncode == 0 and out_mp4_path.exists()


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_queue(queue_path: Path) -> Dict[str, Any]:
    """Load and validate the Gate G5 JSON queue file."""
    if not queue_path.exists():
        raise FileNotFoundError(f"Queue JSON file not found: {queue_path}")
    data = json.loads(queue_path.read_text(encoding="utf-8"))
    if "queue" not in data or not isinstance(data["queue"], list):
        raise ValueError(f"Invalid G5 queue schema in {queue_path}: missing 'queue' list.")
    return data


def is_already_generated(out_file: Path) -> bool:
    """Return True if the target image file already exists and is non-corrupted."""
    if not out_file.exists() or out_file.stat().st_size < MIN_VALID_IMAGE_BYTES:
        return False
    if Image is not None:
        try:
            with Image.open(out_file) as img:
                img.verify()
            return True
        except Exception:
            return False
    return True


def save_ledger(ledger_path: Path, ledger: Dict[str, Any]) -> None:
    """Atomically persist the batch progress ledger to disk."""
    tmp_path = ledger_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp_path.replace(ledger_path)


def generate_single_image_active_gemini(
    api_key: str,
    prompt: str,
    reference_paths: List[Path],
    aspect_ratio: str = "16:9",
    model_name: str = DEFAULT_PRIMARY_IMAGE_MODEL,
) -> bytes:
    """Generate a 16:9 image using active Google Gemini image models (`gemini-3-pro-image`,
    `gemini-nano-banana-2.1`, or `gemini-3.1-flash-image`) with header-authenticated REST API."""
    active_model = assert_active_model(model_name)
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{active_model}:generateContent"

    parts: List[Dict[str, Any]] = [{"text": prompt}]
    for ref_p in reference_paths:
        if ref_p.exists() and ref_p.is_file():
            raw_ref = ref_p.read_bytes()
            mime = "image/jpeg" if raw_ref[:2] == b"\xff\xd8" else "image/png"
            parts.append({
                "inlineData": {
                    "mimeType": mime,
                    "data": base64.b64encode(raw_ref).decode("utf-8"),
                }
            })

    body = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "responseModalities": ["IMAGE"],
            "imageConfig": {"aspectRatio": aspect_ratio, "imageSize": "2K"},
        },
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    for cand in data.get("candidates") or []:
        for part in (cand.get("content") or {}).get("parts") or []:
            inline = part.get("inlineData") or part.get("inline_data")
            if inline and inline.get("data"):
                return base64.b64decode(inline["data"])

    reason = (data.get("promptFeedback") or {}).get("blockReason") or "No inline image returned by Gemini API."
    raise RuntimeError(f"{active_model} returned no image: {reason}")


def generate_with_retry(
    api_key: str,
    item: Dict[str, Any],
    ref_dir: Path,
    model_name: str = DEFAULT_PRIMARY_IMAGE_MODEL,
    use_multimodal_refs: bool = True,
    max_retries: int = 5,
    base_backoff_sec: float = 10.0,
) -> bytes:
    """Execute image generation with exponential backoff on rate limits (429) or transient server errors."""
    active_model = assert_active_model(model_name)
    prompt = str(item.get("query") or "").strip()
    aspect_ratio = str(item.get("aspect_ratio") or "16:9")
    ref_names = item.get("image_references") or []
    ref_paths = [ref_dir / r for r in ref_names if (ref_dir / r).exists()] if use_multimodal_refs else []

    for attempt in range(1, max_retries + 1):
        try:
            return generate_single_image_active_gemini(
                api_key=api_key,
                prompt=prompt,
                reference_paths=ref_paths,
                aspect_ratio=aspect_ratio,
                model_name=active_model,
            )
        except urllib.error.HTTPError as http_err:
            status_code = http_err.code
            err_body = redact_secrets_from_text(http_err.read().decode("utf-8", errors="replace")[:200])
            is_rate_limit = status_code == 429 or "RESOURCE_EXHAUSTED" in err_body.upper()
            wait_sec = base_backoff_sec * (2 ** (attempt - 1)) if is_rate_limit else base_backoff_sec * attempt
            print(
                f"    [WARN] HTTPError (code={status_code}) on attempt {attempt}/{max_retries}: {err_body}",
                flush=True,
            )
            if attempt == max_retries:
                raise RuntimeError(f"HTTP {status_code}: {err_body}") from None
            time.sleep(wait_sec)
        except Exception as err:
            safe_err = redact_secrets_from_text(str(err))
            wait_sec = base_backoff_sec * attempt
            print(
                f"    [WARN] Error on attempt {attempt}/{max_retries}: {safe_err}",
                flush=True,
            )
            if attempt == max_retries:
                raise RuntimeError(safe_err) from None
            time.sleep(wait_sec)

    raise RuntimeError(f"Exhausted all {max_retries} retries for {item.get('asset_id')}.")


def run_batch(
    queue_path: Path,
    output_dir: Path,
    ref_dir: Path,
    api_key: Optional[str] = None,
    model_name: str = DEFAULT_PRIMARY_IMAGE_MODEL,
    use_multimodal_refs: bool = True,
    delay_between_requests_sec: float = 4.5,
    max_retries: int = 5,
    limit: Optional[int] = None,
    segment_filter: Optional[str] = None,
) -> int:
    """Main worker loop: processes all 168 items with resume/skip, rate-limit pacing, and checkpointing."""
    load_project_env()
    active_model = resolve_or_migrate_model(model_name)
    resolved_key = (api_key or os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()
    if not resolved_key:
        print(
            "[ERROR] GEMINI_API_KEY environment variable is not set.\n"
            "Ensure env_config_v4.env is present on Google Drive or set GEMINI_API_KEY.",
            file=sys.stderr,
        )
        return 1

    queue_doc = load_queue(queue_path)
    items: List[Dict[str, Any]] = queue_doc["queue"]

    if segment_filter:
        items = [x for x in items if x.get("segment_id") == segment_filter]

    total = len(items)
    output_dir.mkdir(parents=True, exist_ok=True)
    for bucket_sub in ("10pct_maps_and_diagrams", "30pct_photo_collage", "60pct_video_keyframes"):
        (output_dir / bucket_sub).mkdir(parents=True, exist_ok=True)

    ledger_path = output_dir / "g5_generation_ledger.json"
    ledger: Dict[str, Any] = {
        "episode_id": queue_doc.get("episode_id", "ep_toba_74000bce_12min"),
        "model": active_model,
        "started_at_utc": _utc_now(),
        "total_queued": total,
        "completed_count": 0,
        "skipped_existing_count": 0,
        "failed_count": 0,
        "completed_assets": {},
        "failed_assets": {},
    }
    if ledger_path.exists():
        try:
            old_ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
            ledger["completed_assets"] = old_ledger.get("completed_assets", {})
        except Exception:
            pass

    rendered_this_run = 0
    start_ts = time.time()

    for idx, item in enumerate(items, start=1):
        asset_id = str(item.get("asset_id") or f"frame_{idx:03d}")
        shot_id = str(item.get("shot_id") or "?")
        seg_id = str(item.get("segment_id") or "?")
        bucket = str(item.get("bucket") or "60pct_video_keyframes")
        frame_role = str(item.get("frame_role") or "start_frame")

        flat_out_path = output_dir / f"{asset_id}.png"
        bucket_out_path = output_dir / bucket / f"{asset_id}.png"

        if is_already_generated(flat_out_path):
            ledger["skipped_existing_count"] += 1
            ledger["completed_assets"][asset_id] = str(flat_out_path)
            continue

        if limit is not None and rendered_this_run >= limit:
            break

        t0 = time.time()
        try:
            img_bytes = generate_with_retry(
                api_key=resolved_key,
                item=item,
                ref_dir=ref_dir,
                model_name=active_model,
                use_multimodal_refs=use_multimodal_refs,
                max_retries=max_retries,
            )
            flat_out_path.write_bytes(img_bytes)
            bucket_out_path.write_bytes(img_bytes)

            dt = time.time() - t0
            rendered_this_run += 1
            ledger["completed_count"] += 1
            ledger["completed_assets"][asset_id] = {
                "path": str(flat_out_path),
                "bucket_path": str(bucket_out_path),
                "bytes": len(img_bytes),
                "model": active_model,
                "generated_at_utc": _utc_now(),
                "render_sec": round(dt, 2),
            }
            save_ledger(ledger_path, ledger)

            if idx < total:
                time.sleep(delay_between_requests_sec)

        except Exception as exc:
            safe_err = redact_secrets_from_text(str(exc))
            ledger["failed_count"] += 1
            ledger["failed_assets"][asset_id] = {
                "shot_id": shot_id,
                "error": safe_err,
                "failed_at_utc": _utc_now(),
            }
            save_ledger(ledger_path, ledger)
            print(f"    [FAIL] Could not generate {asset_id}: {safe_err}", file=sys.stderr, flush=True)

    return 0 if ledger["failed_count"] == 0 else 2


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gate G5 Autonomous Gemini Batch Image Generator (Explainer Engine v4.2)."
    )
    parser.add_argument("--queue", type=Path, default=Path(DEFAULT_QUEUE_FILE))
    parser.add_argument("--out", type=Path, default=Path(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--refs", type=Path, default=Path(DEFAULT_REFERENCE_DIR))
    parser.add_argument("--model", type=str, default=DEFAULT_PRIMARY_IMAGE_MODEL)
    parser.add_argument("--use-multimodal-refs", action="store_true", default=True)
    parser.add_argument("--delay", type=float, default=4.5)
    parser.add_argument("--retries", type=int, default=5)
    parser.add_argument("--segment", type=str, default=None)
    parser.add_argument("--limit", type=int, default=None)
    return parser.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    raise SystemExit(
        run_batch(
            queue_path=args.queue,
            output_dir=args.out,
            ref_dir=args.refs,
            model_name=args.model,
            use_multimodal_refs=args.use_multimodal_refs,
            delay_between_requests_sec=args.delay,
            max_retries=args.retries,
            limit=args.limit,
            segment_filter=args.segment,
        )
    )
