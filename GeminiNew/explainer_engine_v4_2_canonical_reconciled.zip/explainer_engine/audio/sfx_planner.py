"""Gate G4 SFX (Footsteps, Foley), Ambience Beds, Musical Melodies & Shot Sound-Design Metadata Planner (D-124 / v4.2).

Integrates directly with `explainer_engine.audio.layers` (`AL-01..AL-08`) and sourced rules:
- `BP-54`: Picture-synced SFX (footsteps, hooves, cannon, doors, parchment) land at 0ms offset (never early).
- `BP-62`: Musical melodies fade in over 1.0s and fade out over 2.0s (`MUSIC_FADE_IN`, `MUSIC_FADE_OUT`).
- `BP-65`: Ambience beds sit at or below `MAX_BED_DB` (-24 dB under speech) and cover the full segment.
- Section 7.4 Shot Sound-Design Metadata (`build_shot_sound_design_metadata`):
  Populates `environment`, `weather`, `surface`, `physical_actions`, `sound_events`, `event_timestamps`,
  `sound_source` (`existing_asset` | `licensed_local` | `procedural` | `model_audio`),
  `spatial_context` (`indoor` | `outdoor` | `close` | `medium` | `distant`),
  `continuity_group`, `suggested_intensity`, and `mixing_priority` for every shot.
"""
from __future__ import annotations

from typing import Any, Dict, List
from explainer_engine.audio import layers as L

FOOTSTEP_KEYWORDS = ("walk", "march", "step", "run", "advance", "retreat", "corridor", "cobblestone", "mud", "flee", "trek")
CAVALRY_KEYWORDS = ("horse", "cavalry", "dragoon", "cuirassier", "gallop", "ride", "mount", "hooves")
COMBAT_KEYWORDS = ("cannon", "battery", "artillery", "fire", "gun", "bayonet", "explosion", "breach", "erupt", "volcan", "caldera", "pyroclastic", "shockwave")
METAL_CLASH_KEYWORDS = ("sword", "blade", "saber", "steel", "clash", "spear", "shield", "armor")
PAPER_LEDGER_KEYWORDS = ("map", "ledger", "bond", "scroll", "dispatch", "letter", "divider", "coin", "gold", "counter", "timeline")
FIRE_KEYWORDS = ("fire", "torch", "candle", "ember", "hearth", "magma", "lava", "burn", "ash")
WATER_KEYWORDS = ("sea", "ocean", "ship", "wave", "river", "harbor", "lake", "water")


def build_shot_sound_design_metadata(
    shot: Dict[str, Any],
    shot_start_sec: float = 0.0,
    has_existing_audio_pack: bool = True,
) -> Dict[str, Any]:
    """Build the canonical Section 7.4 `sound_design` metadata object for a single shot.

    Note on Wan 2.1/2.2 Audio Capability:
    Wan 2.1/2.2 `WAN_I2V`, `WAN_FLF2V`, and `WAN_CONTROL` generate silent video clips (0 audio channels).
    Therefore `model_audio` is only applicable when a clip explicitly carries verified native audio; otherwise
    all environmental ambience and foley are sourced from `existing_asset`, `licensed_local`, or `procedural`.
    """
    sid = str(shot.get("shot_id") or "S01_SH001")
    seg_id = str(shot.get("segment_id") or "S01")
    loc_id = str(shot.get("location_id") or "loc_default")
    dur = float(shot.get("target_duration_seconds", 4.0))
    shot_size = str((shot.get("camera_spec") or {}).get("shot_size") or "medium_wide")

    text_blob = " ".join([
        str(shot.get("narrative_purpose") or ""),
        str(shot.get("action_start_state") or ""),
        str(shot.get("action_end_state") or ""),
        str(shot.get("lighting_and_time") or ""),
        loc_id,
    ]).lower()

    # 1. Indoor vs Outdoor & Environment classification
    is_indoor = any(k in text_blob for k in ("interior", "room", "hall", "chamber", "tent", "cave", "shelter", "vault", "library", "palace"))
    if any(k in text_blob for k in ("volcan", "caldera", "toba", "crater", "ash")):
        environment = "volcanic_caldera_and_ash_plains"
    elif any(k in text_blob for k in ("battle", "ridge", "field", "trench", "front")):
        environment = "battlefield_exterior"
    elif any(k in text_blob for k in WATER_KEYWORDS):
        environment = "coastal_or_maritime"
    elif is_indoor:
        environment = "stone_or_timber_interior"
    else:
        environment = "open_wilderness_exterior"

    # 2. Weather
    if any(k in text_blob for k in ("ash", "eruption", "pyroclastic")):
        weather = "volcanic_ash_storm_and_wind"
    elif any(k in text_blob for k in ("rain", "storm", "downpour", "thunder", "monsoon")):
        weather = "heavy_rain_and_wind"
    elif any(k in text_blob for k in ("snow", "frost", "winter", "blizzard", "glacial")):
        weather = "freezing_wind_and_snow"
    elif is_indoor:
        weather = "enclosed_draft"
    else:
        weather = "high_altitude_wind"

    # 3. Surface
    if any(k in text_blob for k in ("snow", "ice", "frost")):
        surface = "snow"
    elif any(k in text_blob for k in ("stone", "cobble", "rock", "basalt", "marble", "cave")):
        surface = "stone"
    elif any(k in text_blob for k in ("grass", "forest", "meadow", "jungle")):
        surface = "grass"
    else:
        surface = "dirt"

    # 4. Physical actions, sound events & timestamps
    physical_actions: List[str] = []
    sound_events: List[str] = []
    event_timestamps: List[float] = []

    if any(k in text_blob for k in COMBAT_KEYWORDS):
        physical_actions.append("volcanic_or_artillery_rupture")
        sound_events.append("volcanic_explosion_debris")
        event_timestamps.append(round(shot_start_sec + min(0.25, dur * 0.15), 3))
    if any(k in text_blob for k in METAL_CLASH_KEYWORDS):
        physical_actions.append("weapon_or_metal_impact")
        sound_events.append("sword_metal_clash")
        event_timestamps.append(round(shot_start_sec + min(0.45, dur * 0.25), 3))
    if any(k in text_blob for k in CAVALRY_KEYWORDS):
        physical_actions.append("cavalry_movement")
        sound_events.append("horse_hooves_gallop")
        event_timestamps.append(round(shot_start_sec + 0.12, 3))
    if any(k in text_blob for k in FOOTSTEP_KEYWORDS):
        physical_actions.append(f"footsteps_on_{surface}")
        sound_events.append(f"footstep_{surface}")
        event_timestamps.append(round(shot_start_sec + 0.18, 3))
    if any(k in text_blob for k in FIRE_KEYWORDS):
        physical_actions.append("fire_and_ember_convection")
        sound_events.append("fire_crackle_bed")
        event_timestamps.append(round(shot_start_sec + 0.05, 3))
    if any(k in text_blob for k in PAPER_LEDGER_KEYWORDS) or shot.get("generation_mode") in ("TACTILE_MAP", "MAP_25D"):
        physical_actions.append("cartographic_data_reveal")
        sound_events.append("page_flip")
        event_timestamps.append(round(shot_start_sec + 0.05, 3))

    if not sound_events:
        physical_actions.append("atmospheric_camera_drift")
        sound_events.append("wind_howl" if not is_indoor else "cloth_rustle")
        event_timestamps.append(round(shot_start_sec + 0.10, 3))

    # 5. Spatial context
    if shot_size in ("close_up", "extreme_close_up", "medium_close_up"):
        distance_tag = "close"
    elif shot_size in ("extreme_wide", "wide", "top_down_map"):
        distance_tag = "distant"
    else:
        distance_tag = "medium"
    spatial_context = f"{'indoor' if is_indoor else 'outdoor'}_{distance_tag}"

    # 6. Continuity group: consecutive shots in the same location or environment share an unbroken ambience bed
    continuity_group = f"amb_group_{loc_id}_{'indoor' if is_indoor else 'outdoor'}"

    return {
        "shot_id": sid,
        "segment_id": seg_id,
        "environment": environment,
        "weather": weather,
        "surface": surface,
        "physical_actions": physical_actions,
        "sound_events": sound_events,
        "event_timestamps": event_timestamps,
        "sound_source": "existing_asset" if has_existing_audio_pack else "procedural",
        "spatial_context": spatial_context,
        "continuity_group": continuity_group,
        "suggested_intensity": "high" if any(k in text_blob for k in COMBAT_KEYWORDS) else ("low" if is_indoor else "medium"),
        "mixing_priority": "duck_under_narration_and_dialogue",
    }


def build_g4_audio_fx_plan(script_doc: Dict[str, Any]) -> Dict[str, Any]:
    """Generate the Gate G4 SFX, Footsteps, Ambience, Musical Melody & Shot Sound-Design manifest from production_script.json."""
    segments = script_doc.get("segments", [])
    shots = script_doc.get("shots", [])
    sfx_cues: List[Dict[str, Any]] = []
    ambience_beds: List[Dict[str, Any]] = []
    music_melodies: List[Dict[str, Any]] = []
    shot_sound_design_map: Dict[str, Dict[str, Any]] = {}

    t_cursor = 0.0
    for idx_sh, sh in enumerate(shots):
        dur = float(sh.get("target_duration_seconds", 4.0))
        shot_id = sh.get("shot_id", "?")
        seg_id = sh.get("segment_id", "?")
        text_blob = " ".join([
            str(sh.get("narrative_purpose", "")),
            str(sh.get("action_start_state", "")),
            str(sh.get("action_end_state", "")),
        ]).lower()

        sd_meta = build_shot_sound_design_metadata(sh, shot_start_sec=t_cursor)
        shot_sound_design_map[shot_id] = sd_meta

        # Anti-repetition variant index (1, 2, 3) so adjacent shots never play the exact same sample without variation
        variant_idx = (idx_sh % 3) + 1

        if any(k in text_blob for k in FOOTSTEP_KEYWORDS):
            sfx_cues.append({
                "cue_id": f"SFX_{shot_id}_FOOTSTEPS",
                "shot_id": shot_id,
                "segment_id": seg_id,
                "category": "footsteps_foley",
                "sound": f"footstep_{sd_meta['surface']}_v{variant_idx}",
                "generator_key": f"footstep_{sd_meta['surface']}",
                "variant_seed": variant_idx,
                "pitch_jitter": round(1.0 + ((idx_sh % 5) - 2) * 0.025, 4),
                "start_sec": round(t_cursor + 0.15, 3),
                "duration_sec": round(min(2.5, dur - 0.2), 3),
                "gain_db": -14.0,
                "offset_ms": 0,  # BP-54: never early
            })
        if any(k in text_blob for k in CAVALRY_KEYWORDS):
            sfx_cues.append({
                "cue_id": f"SFX_{shot_id}_HOOVES",
                "shot_id": shot_id,
                "segment_id": seg_id,
                "category": "cavalry_foley",
                "sound": f"horse_hooves_and_tack_v{variant_idx}",
                "generator_key": "horse_hooves_gallop",
                "variant_seed": variant_idx,
                "pitch_jitter": round(1.0 + ((idx_sh % 3) - 1) * 0.03, 4),
                "start_sec": round(t_cursor + 0.10, 3),
                "duration_sec": round(min(3.0, dur - 0.2), 3),
                "gain_db": -13.0,
                "offset_ms": 0,
            })
        if any(k in text_blob for k in COMBAT_KEYWORDS):
            sfx_cues.append({
                "cue_id": f"SFX_{shot_id}_CANNON",
                "shot_id": shot_id,
                "segment_id": seg_id,
                "category": "battlefield_impact",
                "sound": f"distant_cannon_salvo_and_smoke_v{variant_idx}",
                "generator_key": "volcanic_explosion_debris",
                "variant_seed": variant_idx,
                "pitch_jitter": round(1.0 + ((idx_sh % 4) - 1.5) * 0.03, 4),
                "start_sec": round(t_cursor + 0.25, 3),
                "duration_sec": 2.0,
                "gain_db": -12.0,
                "offset_ms": 0,
            })
        if any(k in text_blob for k in PAPER_LEDGER_KEYWORDS) or sh.get("generation_mode") in ("TACTILE_MAP", "MAP_25D"):
            sfx_cues.append({
                "cue_id": f"SFX_{shot_id}_TACTILE",
                "shot_id": shot_id,
                "segment_id": seg_id,
                "category": "tactile_artifact_foley",
                "sound": f"vellum_parchment_and_brass_compass_v{variant_idx}",
                "generator_key": "page_flip",
                "variant_seed": variant_idx,
                "pitch_jitter": 1.0,
                "start_sec": round(t_cursor + 0.05, 3),
                "duration_sec": 1.5,
                "gain_db": -15.0,
                "offset_ms": 0,
            })
        if not any(c["shot_id"] == shot_id for c in sfx_cues):
            # Ensure every shot has a grounded subtle foley cue
            gen_key = sd_meta["sound_events"][0]
            sfx_cues.append({
                "cue_id": f"SFX_{shot_id}_ENV_FOLEY",
                "shot_id": shot_id,
                "segment_id": seg_id,
                "category": "environmental_foley",
                "sound": f"{gen_key}_v{variant_idx}",
                "generator_key": gen_key,
                "variant_seed": variant_idx,
                "pitch_jitter": round(1.0 + ((idx_sh % 3) - 1) * 0.02, 4),
                "start_sec": round(t_cursor + 0.12, 3),
                "duration_sec": round(min(2.0, dur - 0.15), 3),
                "gain_db": -16.0,
                "offset_ms": 0,
            })
        t_cursor += dur

    # Build continuous ambience beds grouped by continuity_group across consecutive shots + segment beds
    seg_cursor = 0.0
    for idx, seg in enumerate(segments):
        sdur = float(seg.get("target_duration_seconds", 60.0))
        sid = seg.get("segment_id", f"S{idx+1:02d}")
        fstatus = seg.get("factual_status", "actual_history")
        ambience_beds.append({
            "bed_id": f"BED_{sid}",
            "segment_id": sid,
            "continuity_group": f"seg_continuity_{idx // 2}",
            "sound": "rain_and_wind_battlefield_bed" if idx % 2 == 0 else "london_exchange_hall_murmur_bed",
            "start_sec": round(seg_cursor, 3),
            "end_sec": round(seg_cursor + sdur, 3),
            "crossfade_sec": 0.65,
            "gain_db": float(L.MAX_BED_DB),  # BP-65 cap (-24 dB)
        })
        melody_mood = {
            "actual_history": "cello_tension_ostinato_d_minor",
            "divergence_point": "brass_and_timpani_turning_point_motif",
            "counterfactual_consequence": "driving_strings_escalation_melody",
            "historical_reflection": "solemn_piano_and_low_strings_resolution",
        }.get(fstatus, "cello_tension_ostinato_d_minor")
        music_melodies.append({
            "music_id": f"MELODY_{sid}",
            "segment_id": sid,
            "motif": melody_mood,
            "start_sec": round(seg_cursor, 3),
            "end_sec": round(seg_cursor + sdur, 3),
            "fade_in_s": 1.0,   # BP-62
            "fade_out_s": 2.0,  # BP-62
            "duck_under_speech_db": -18.0,
        })
        seg_cursor += sdur

    return {
        "schema": "g4_audio_fx_plan/2",
        "episode_id": script_doc.get("episode_id", "unknown"),
        "status": "AWAITING_CREATOR_G4_APPROVAL",
        "sourced_rules_enforced": ["AL-01..AL-08", "BP-53", "BP-54", "BP-57", "BP-62", "BP-65", "BP-116..BP-122"],
        "wan_video_native_audio_note": "Wan 2.1/2.2 I2V/FLF2V generate silent video clips; 100% of environmental ambience and spot foley are provided by this continuous sound-design layer.",
        "counts": {
            "sfx_cues": len(sfx_cues),
            "ambience_beds": len(ambience_beds),
            "music_melodies": len(music_melodies),
            "shots_with_sound_design_metadata": len(shot_sound_design_map),
        },
        "shot_sound_design": shot_sound_design_map,
        "sfx_cues": sfx_cues,
        "ambience_beds": ambience_beds,
        "music_melodies": music_melodies,
    }
