# Script engine v1 (2026-10-24)

> **Route-scoped since D-116 (2026-11-06):** these rules apply to J2/J4 shots and to the Qwen assets of J5 ([route plan](architecture/ROUTE_PLAN_2026-11-06.md), [decision log](DECISIONS_AND_OPEN_QUESTIONS.md) D-96 as amended, D-116); the 2026-11-05 legacy banner below is history and stays readable.

> **Legacy (image-generation era) note, 2026-11-05 (ICW-01, D-96).** Where this page names Qwen keyframes, LTX clips, sprites, painted pictures or 2.5D stills as the production path, it describes the legacy image-generation route (D-43, D-80, D-105); the Ink Chronicle Blender lanes follow D-97 and the decision log wins on a conflict (CLAUDE.md precedence rule). Everything else on this page stays in force.


## Canonical v4.0 Single-Source-of-Truth Script & 4-Stage Routing (D-123)
- **Canonical Manual & Schema:** See [MAIN_METHOD](MAIN_METHOD.md) and `explainer_engine/schemas/production_script.schema.json` (`v4.0.0`). One canonical `production_script.json` holds `world_bible`, `phases` (`Z1-Z5`), `segments` (`S01-S16`), `audio_lines`, and `shots`.
- **Stage 2 & Stage 3 Generation Modes (Superseding `J1-J5` as Default):** Each shot routes to `WAN_I2V`, `WAN_FLF2V`, selective `WAN_CONTROL`, `STILL_25D`, or `MAP_25D` ([VIDEO_GENERATION_WAN](VIDEO_GENERATION_WAN.md)).
- **Preserved Lints:** `claims.py`, `narration_lint.py`, `register_lint.py`, `rhythm_lint.py`, and `shot_prompt_lint.py` enforce zero improvisation and anti-overconditioning (`primary_action_count == 1`, `camera_move_count <= 1`).

**What it is.** The one path from a topic to every prompt of an animated episode, with nothing left to improvise: each
dimension of a prompt or a script is either set by a rule with a source or marked as a variant under test. ვანო asked for
it on 2026-10-24 ("zero improvisation; where a rule is missing, research it, then write it"). The first episode written
on it is [`examples/napoleon_vs_genghis/`](../examples/napoleon_vs_genghis/) (214 shots, 15:00, 0 FAIL, 0 REVIEW).
The evidence for the new numbers is [research/SCRIPT_ENGINE_V1_2026-10-24.md](research/SCRIPT_ENGINE_V1_2026-10-24.md).

## 1. The pipeline

| # | Stage | Input -> output | Rules | Tool / check | Who approves |
|---|---|---|---|---|---|
| 1 | Research | topic -> claim map (id, text, source, kind fact / estimate / invented) | invariant 5; ZI-02, ZI-04 | the `claims` block of the cards | - |
| 1b | Variants | dossier -> two or three priced variants of different structure profiles, each scored by code (VP) | ZI-07, ZI-08; VP-01..VP-18 | `python -m explainer_engine.scripting.variant_plan` | creator card (VARIANT_CHOSEN, [OR-31](ORCHESTRATION.md)) |
| 2 | Skeleton | claim map -> the 16 segments of template D with their clock | [STORY_ENGINE.md](STORY_ENGINE.md) template D, ST-17..ST-19 | `scripting/story_lint.py` | creator (scenario, OR-15) |
| 3 | Shot cards | skeleton -> `film_shots/1` cards: narration, dialogue, blocking, action, tier, claims | [SHOT_PROMPTS.md](SHOT_PROMPTS.md) KP-15..KP-43 | `python -m explainer_engine.scripting.film_shots check` | creator (script) |
| 4 | Script | cards -> the readable script and the narrator's lines; the shot list with every prompt under its shot | ZI-01 | `film_shots script --out script.md`, `film_shots shotlist --out shotlist.md` | - |
| 5 | Prompts | cards -> hero-sheet, keyframe, next-pose, cut, last-frame and video prompts, gate cards | ZI-01, ZI-05, KP-01..KP-14 | `film_shots compose --out prompts.json` | creator picks each new hero from its sheet (invariant 6) |
| 6 | Pictures | prompts -> sheets, masters, poses and cuts: Qwen-Image-2.1 + the xworld_v2 LoRA (D-80, ZI-06, KG-16); continuity through continuity_card/1 ([SHOT_CONTINUITY](SHOT_CONTINUITY.md)); weights, steps and sizes: [LORA_TRAINING](LORA_TRAINING.md) LT-79 | ZI-06; the keyframe gate of PR #22 | gate cards in `prompts.json` | paint plan + provider (D-50) |
| 7 | Clips | first (and last) frame + video prompt -> clip with native audio (a dialogue shot: conditioned on its read take, D-90) | ZI-03, ZI-06; KP-36, KP-37 | video QA of PR #22 | paid run approved first |
| 8 | Narrator | `script.md` narrator lines -> ElevenLabs read + word timings | skill `elevenlabs-voice` | `audio/scribe_words.py` | - |
| 9 | Edit | clips + read -> 15-minute cut, 1440p release (test cuts at the base size, LT-18) | [EDITING.md](EDITING.md) | `production/assemble.py` | creator approval before upload |

## 2. The rules

| ID | Rule | Why | Check |
|---|---|---|---|
| ZI-01 | **Every prompt is composed from a card**: hero sheets, keyframes, next poses, cuts, last frames and video prompts come only from `film_shots compose`; a prompt typed by hand is not used, and a gap in the composer is fixed in the composer (with a test), never patched in one prompt | one card, every model's grammar the same (KP-30) | [code] `compose` |
| ZI-02 | **A number needs a claim.** A narrator line with a number (a digit, a year, "hundred", "half", "nine") lists claim ids, and every listed id is in the claim map with a source; a fact the story invents is a claim of kind `invented` | invariant 5: no unsupported claims | [code] FAIL |
| ZI-03 | **Every shot has an animation tier** (`hold`, `light`, `full`, KP-37) under `"engine": "script_engine/1"`; the tier picks the model (section 3) | the critic's plan and the measured cartoons disagreed; the card has to say which budget it spends | [code] FAIL |
| ZI-04 | **Inventions are listed.** Everything the story makes up that a viewer could take for history (the premise, a person's presence, a battle and its numbers, every line of dialogue) has an `invented` claim, and the description of the video says the story is fiction | invariant 5; YouTube's disclosure is decided per video (CLAUDE.md) | the claim map; editorial |
| ZI-05 | **A variant under test is named, not guessed.** Where a test is still running (sizes in words or numbers, 24 or 12 fps, the tier shares), the cards use the variant in section 3 and the package names it; the winner of the test replaces it in section 3 and nowhere else | the creator 2026-10-24: "use the one that looks ideal in theory, say which" | section 3 |
| ZI-06 | **A LoRA runs only on its own base, and the base is Qwen-Image-2.1** ([D-80](DECISIONS_AND_OPEN_QUESTIONS.md), 2026-10-26): 2.1 draws and edits with references; 2512, Edit-2511 and every old `wldnk_*` LoRA are retired; each shot is made once and redrawn only when its check fails | the style-weight test 2026-10-24; ვანო 2026-10-26 01:15 | [code] `keyframe_gate.check_stack` |
| ZI-07 | **No scenario without a chosen variant.** The scenario stage reads `script_variants.json` whose `chosen` is set and whose `variants_sha256` matches the file; the procedure is [OR-31](ORCHESTRATION.md). | cost and structure are chosen before a word is written, by the creator | [code] `EpisodeJob.move` ([CN-04](CONTRACTS.md)) |
| ZI-08 | **The chosen variant binds the script.** Profile, segment lanes and packaging promises are copied from it, never re-chosen; a drift is VP-15. | the pick must not be rewritten quietly | [code] VP-15 |
| ZI-09 | **No AI register in anything the viewer hears or reads.** `register_lint` ([RG rules](STORY_ENGINE.md)) runs on the script (PV-61), the narration (N-16, N-17) and the cards and HUD text (KP-46). | the creator's point 1 of 2026-10-29: a script must not read as machine writing | [code] RG-01 FAIL |
| ZI-10 | **The spine is compiled, never written by hand.** `screenplay_spine.json` comes only from `production compile --film-shots`; its three packaging promises are locked by the script approval (PV-53). | a hand-edited spine would drift from the script it is derived from | [code] [CN-02](CONTRACTS.md) |

## Variant planner checks (VP)

Stage 1b (`scripting/variant_plan.py`, [OR-31](ORCHESTRATION.md)) writes two or three priced variants of different profiles before the
scenario; code scores them with the checks below, the critic scores the story, the creator picks on one card. A check is a function of
`variant_plan.dynamics()`, the one place that counts lane shares (the plan, the script and later the shot router call it).
Score = 100 - 10 per REVIEW - 25 per FAIL, floor 0; a variant with a FAIL cannot be picked. The score never replaces or adds to
the critic's.

| ID | Check | Severity |
|---|---|---|
| VP-01 | the blocks of every segment add up to its window and the shares to 1 (a contract fault) | FAIL (invariant 7) |
| VP-02 | pure map share at most [BP-109](SOURCED_RULES.md)'s helper lane plus its tolerance (a map is a helper visual, D-93) | REVIEW |
| VP-03 | the non-character share at most the profile's `non_character_max` | REVIEW |
| VP-04 | the longest run of pure map at most `map_run_max_s` | REVIEW |
| VP-05 | the longest run without a played block at most [BP-127](SOURCED_RULES.md)'s `non_character_run_max_s` | REVIEW |
| VP-06 | the same archetype on two adjacent narrated blocks | REVIEW |
| VP-07 | more than `rotation_family_max` blocks of one archetype family inside `rotation_window_s` | REVIEW |
| VP-08 | a turn slot with no played block that has a cast member ([BP-142](SOURCED_RULES.md): every turn is a played scene) | FAIL (house) |
| VP-09 | the played share of a turn slot below the profile's `turn_scene_share_min` | REVIEW |
| VP-10 | one compensator picture longer than `kuleshov_max_s` | REVIEW |
| VP-11 | a scheduled lane or archetype does not exist in code yet (one finding per lane, naming its phase) | REVIEW |
| VP-12 | a cost row is `unknown` (no measurement in `config/job_speeds.json`): the variant waits for its measuring phase | REVIEW |
| VP-13 | the known worst-case cost above 80 % of a cap of `config/spend_caps.json` (invariant 2) | FAIL |
| VP-14 | two variants of one profile (a near-copy) | REVIEW |
| VP-15 | drift from the choice: seconds per segment beyond [BP-146](SOURCED_RULES.md)'s `seconds_drift` or cost beyond `usd_drift` of the planned price: REVIEW; cost above the `usd_worst` the creator approved: FAIL (invariant 2) | REVIEW / FAIL |
| VP-16 | the estimated narrator share outside [BP-105](SOURCED_RULES.md)'s band | REVIEW |
| VP-17 | the central scene (slot 10) has the most played seconds (ST-18) | REVIEW |
| VP-18 | planned shots per minute outside [BP-107](SOURCED_RULES.md)'s band, or a planned lane share (video / still / helper) outside [BP-109](SOURCED_RULES.md)'s 60 / 30 / 10 plus or minus its tolerance (D-93) | REVIEW |

Costs come only from `config/job_speeds.json` (pod work, measured by P12b) and the API price tables (`imagegen`); a row with no
measurement is `unknown` and is shown as such, never filled in. A pod row waits for its measurement, an API row does not.

## 3. Variants in use (replace a row when its test reports)

| Dimension | In use now | Alternative under test | Where it is set |
|---|---|---|---|
| Story structure | template D, 16 segments, 900 s; planned as priced variants before the script (stage 1b, ZI-07) and chosen by the creator | profiles B and C (tactical, systems lab) as variants | [STORY_ENGINE.md](STORY_ENGINE.md), BP-141 |
| Figure size in a picture prompt | words ("a third", "most of the frame height"); decided by test v2 2026-10-24 (numbers were drawn as rulers and sized no better) | - | KP-32 |
| A hero's tag in one prompt | the full tag every time the hero is named | the full tag once, then a short name ("the old man"): one figure came out twice in 4 of 4 pictures where a tag repeated three times (test v2, a hypothesis) | `film_shots._people` |
| Keyframe | Qwen-Image-2.1 + the xworld_v2 LoRA (D-80, ZI-06, KG-16); continuity through continuity_card/1 ([SHOT_CONTINUITY](SHOT_CONTINUITY.md)); weights, steps and sizes: [LORA_TRAINING](LORA_TRAINING.md) LT-79 | the retired cells are under History below | `qa/style_prompt.INFERENCE`, LT-79 |
| Keyframe and sheet words | `<trigger>, <the moment>` (the trigger is read from `training/lora_rules.json` through `lora_rules.trigger()`, the one home, N-09), at most 40 words, no tail, no camera, size or position (LT-65): the place's head, the lead (tag, or its head phrase when words run out) with the caricature body words (`style.body`) and the action at its peak, one reaction, the light, then every other figure (KP-45: everyone by the tag's head, their reactions, then costume traits; each tag once, LY-09); sizes, sides, heights, supports, free space and counts are the gate card's layout for the composition of assets (ASSET_COMPOSE), whose first frame keeps the start pose (KP-16) | the long composed layout sentences (v1: up to 337 words) and the v5 caption tail (90 words), retired by PR #22 c032f76 | `film_shots.keyframe_prompt`, `MOMENT_WORDS_MAX` |
| Gate cards | one card for every drawn frame: each first frame (keyframe, next pose, cut; `master` names the picture it was edited from, KG-13) and each guided last frame (`<id>.last`, a lead who exits left out); besides people, relations and free space, a card carries `things` (exact counts from `frame.things` {name: count}, KG-01: one bus is one bus) and `absent` (the world's top-level `absent` plus `frame.absent`, KG-21) | cards for keyframes and cuts only, with no object counts or absent things (the Qwen-Image-2.1 style LoRA drew a second bus and a city, 2026-10-25) | `film_shots.gate_card`, `gate_cards` |
| Episode look and absolutes | every style-LoRA prompt ends with the episode's colour-and-light phrase (`style.look`: a look file or its phrase and `lights`; a shot names a variant with `frame.look`), added by `episode_look.apply`, never by hand (AC-16..AC-17); the moment shrinks so the whole prompt keeps 40 words; the negative is exactly `style_prompt.NEGATIVE` and the inference settings `style_prompt.INFERENCE` (LT-66) | colour words written per prompt, a negative per episode | `film_shots._look`, `style_check` |
| Next pose, cut, last frame | Qwen-Image-2.1 in its edit mode with references and the one xworld_v2 LoRA (no scene LoRA); a next pose opens `<trigger>, a later frame of the same continuous animated shot, same camera:`, a cut opens with the trigger (N-09) | the retired cells are under History below | KP-07, KP-08, KP-27, `film_shots` |
| Video model by tier | `full` -> LTX-2.5 dev (acting, every line, every peak); `light` -> LTX-2.5 distilled (breath, glance, a turn of the head); `hold` -> no video model: the keyframe with our camera move | the cheaper model on `full` shots, after the 1-minute film | `film_shots.MODEL` |
| Scene length (was "Clip length") | a scene limit since D-116 (2026-11-06): visible voiced dialogue/lip-sync coverage at most 5 s; non-dialogue VIDEO action shots may run up to 15 s when continuity benefits the scene; actual model/resolution/fps limits still apply. A guided last frame is not an edit cut. | old universal 10 s cap | BP-108 / D-95 |
| One LTX clip | a J2/J4 shot is cut or chained into LTX generations inside BP-172's clip band (D-116) | one generation per scene | BP-172 / KP-49 |
| Frame rate and frames | 24 fps, 8k + 1 frames covering the shot | 12 fps or 24 fps drawn on twos (the creator's three-variant test film) | `film_shots.frames`, LT-07 |
| Clip size | test films 1280x704 (LTX sizes are multiples of 32), never upscaled; release clips upscaled to 2560x1440 | release clips rendered at 1920x1088 before the upscale | LT-18 |
| Video prompt | one present-tense paragraph: the style sentence, the action start -> peak -> settle, the face, the reactions, the line in quotes with its voice, who stays in frame, one camera sentence, the sounds | - | KP-10..KP-12, KP-18, BP-102 |
| Acting fallback (KP-43) | a line whose take fails the acting check twice: over the speaker's shoulder onto the listener (the line plays on the reaction), or the speaker's hands for a line said to the room | redraw the same shot a third time | `film_shots._acting` |
| Dialogue audio | a fixed ElevenLabs voice per speaking character (cast card `voice_id`), the line read first and the take given to LTX as its audio input (D-90; the wiring is P6/P7, not built yet) | LTX native audio with the voice described in words (superseded by D-90, card A3) | the cast cards, D-90 |
| Narrator | ElevenLabs, the script's narrator lines, first take | - | skill `elevenlabs-voice` |
| Spoken mix | nominal 70 % narrator / 30 % voiced character dialogue by audible spoken words, REVIEW outside 65-75 % narrator (D-99, 2026-11-05); `voiced:false` lines are excluded | old 25-45 % narrator mix; D-95's 70-80 % band and 75/25 midpoint | BP-105 / D-99 |
| Visual mix | by runtime 60 % VIDEO (light and full, including non-dialogue action), 30 % STILL (Python adds/moves objects), 10 % HELPER visuals (maps, graphics, calculations); independent from the spoken mix | the creator's call 2026-11-01 (D-93); tolerance ±5 pp | BP-109 / D-93 |

### History (banned by D-80)
Cells that were "in use" before 2026-10-26 and are retired, kept so a reader can tell where an old prompt came from:
- Stage 6: masters on Qwen-Image-2512 + style LoRA, poses and cuts on Edit-2511 + scene LoRA (banned by D-80, ZI-06).
- Keyframe: Qwen-Image-2512 + `wldnk style` LoRA, bf16, 1280x720, 24 steps, true CFG 4 (the settings the frozen LoRA was judged at); alternative 1664x928 at 50 steps.
- Next pose, cut, last frame: Qwen-Image-Edit-2511 + scene LoRA v1 (checkpoint 500-750), the training caption's prefix `nextpose, ...` (retired).
- Keyframe and sheet words began `wldnk style, ` (retired trigger).

## 4. The master prompt (what the writer is given)

The writer of an episode (a person, the `story-architect` and `scene-writer` agents, or a chat) gets this brief, filled in.
Every line points at a rule; nothing in it is new.

1. **Topic and premise.** One sentence of what if, one dramatic question answered at the end (ST-01), and the mixed
   outcome (the channel tells stories, the ending is not a clean win).
2. **Research first.** Write the claim map before a line of story: each historical fact with its source, each invention
   marked `invented` (ZI-02, ZI-04). The heroes' characters come from the sources (how they decided, what they wanted,
   what they feared), the armies' or systems' abilities from numbers with sources.
3. **Skeleton.** Fill template D's 16 segments with what happens in each, in the clock template D gives.
4. **Cards.** Write the shots in `film_shots/1`: a beat for each, the frame (size, place, light, camera), the blocking
   (who stands where, on what, how large), one action with its start, peak and settle, the reactions, the line or the
   narrator's words, the sound, the tier and the claims. A spoken line fits its shot (BP-100); a scene opens wide (KP-26);
   the narrator never describes the picture (KP-20); a scene changes the situation (SC-02).
   **Action, reaction, consequence**: judge a scene by that chain, not by its shot count. A plan is shown while it is
   told (KP-42: the scouts at the wagons while the khan asks what the French eat), the other side's move runs in
   parallel with the hero's win (cross-cutting: the camp burns while Napoleon smiles), the cost lands on screen (spent
   horses, men eating grass), and the cold open shows pieces of the fight to come (KP-41). Talk never rests on AI faces
   alone (KP-43).
5. **Check.** `film_shots check` until 0 FAIL; every REVIEW left is answered in the package.
6. **Compose.** `film_shots compose` and `film_shots script`; the package for the creator holds the skeleton, the script,
   the prompts, the variants in use (section 3) and the claim map.

## 5. Commands

```powershell
.venv\Scripts\python examples\napoleon_vs_genghis\build_cards.py          # the shot list -> film_shots.json
.venv\Scripts\python -m explainer_engine.scripting.film_shots check   examples\napoleon_vs_genghis\film_shots.json
.venv\Scripts\python -m explainer_engine.scripting.film_shots compose examples\napoleon_vs_genghis\film_shots.json --out prompts.json
.venv\Scripts\python -m explainer_engine.scripting.film_shots script  examples\napoleon_vs_genghis\film_shots.json --out script.md
.venv\Scripts\python -m explainer_engine.scripting.film_shots shotlist examples\napoleon_vs_genghis\film_shots.json --out shotlist.md
```
