---
name: scene-writer
description: Stage page (OR-20, D-79): the main agent runs this stage itself, following this page; it is not spawned as a separate agent. Writers' room stage 2. Writes ONE segment of the production script as a played SCENE (narration hand-off plus addressed character dialogue) from the settled story skeleton and the segment's scene header. Use segment by segment after the story architect's skeleton passes story_lint.
model: sonnet
effort: high
tools: Read, Write, Edit, Bash, Grep
---

**Ink Chronicle note (D-96, 2026-11-05):** speech mix nominal 70/30, REVIEW outside 65-75 % narrator words (D-99); visible voiced coverage stays ≤ 5 s (BP-108); where this page names LTX shots it describes the legacy image-generation route (D-105).

At the start of this stage Read this page and every file it says to read first with the Read tool (never work from a remembered copy of them, OR-32), then run `python -m explainer_engine.scripting.stage_guard start writer --job <job> --page .claude/agents/scene-writer.md --input <each file you read>`; at its end `python -m explainer_engine.scripting.stage_guard fresh writer --job <job> <the stage output>` and this stage's own check (the gate column of the skill `story-engine`).

You write the words of one segment: its `lines` (text, `speaker`, `claims`, and on every dialogue line `to`, plus
`intent` where it fits: reveal, press, deflect, concede, question, banter, decide, aside). You do not touch the story
layer, the scene header, the shots, the tags or the sounds (stage guard `writer`). Load the skill `dialogue-scenes`
first and read `docs/STORY_ENGINE.md` (SC and DW rules) and the skill `narration-script` for the narrator's own lines.

Input you get for every segment (and you read nothing else of the script): the whole skeleton (one line per segment,
so you always know where the story goes), this segment's `drama` AND its `scene` header from the architect (place,
time, present, why_now, pov, want, obstacle_want, value, charges, turn, exit, surface_topic, real_subject), the cast
voice bibles (`cast.<id>.speech` with attitude_to_each_other_character and what_they_never_admit), the last three
lines of the previous segment, the next segment's `beat`, and the claim ids this segment may use.

Write:
- A dialogue segment is the hand-off unit (skill `dialogue-scenes`): NARRATOR 2-4 sentences ending on the pressure ->
  the SCENE, 5-12 beats, turning on the header's `turn`, exiting on the header's `exit` -> NARRATOR 1-2 sentences,
  consequence plus the next pressure. The narrator never restates the scene's turn and never quotes a character.
- Every dialogue line is addressed: `to` is a cast id in `present`, or "self"/"room" (SC-04). A hero NEVER answers the
  narrator. Every present hero speaks or reacts (SC-05).
- Enter late, leave early (SC-06): never a greeting opener ("hello", "morning", "welcome"), never a wrap-up closer
  ("so that's", "anyway", "in conclusion"). Start at the first beat of the conflict, end within 1-2 lines of the turn.
- Turn lengths (SC-09, DW-06): default 5-15 words a turn; a line over 35 words is a FAIL; at most one 25-60-word
  `speech` per scene, at its peak. Vary the rhythm patterns and script the silence beat (skill `dialogue-scenes`).
- Non-direct replies (DW-12): never more than 3 clean question->answer pairs in a row; at least 2 deflections,
  questions back, silences or counterattacks per scene.
- Subtext never spoken (SC-10): no line states the header's `real_subject` verbatim; the fight stays on the surface
  topic. Facts enter dialogue only as ammunition under the knowledge-state table (DW-13), ~1 fact per 2-3 beats.
- Animated episodes (shot cards, D-77): no more than four lines in a row on faces (KP-43): after four, a silent
  reaction, an insert or a cutaway; when a character explains a plan, write the shot of it being carried out next
  to the line (KP-42).
- Never press-release narration (SC-07): no "X's page says", "announced", "is set to release", "the trailer confirms".
  A date or spec appears only inside a scene as a stake. Full immersion (SC-08, SC-11, BP-88): no line says the
  story is invented, a simulation or hypothetical, and the narrator never hedges it ("we can't know for sure").
- Show, don't tell (SC-12, BP-87): the narrator never states a trait ("he is ruthless"), a rating or a biography; write
  the action, the line, the mistake or the decision that shows it.
- Each hero talks like their bible (DW-11): manner, signature moves, what they never admit; cover the names and the
  reader can still tell who speaks (DW-03). Every factual sentence carries its claim id.
- Narration between scenes stays the friendly guide (skill `narration-script`): short spoken sentences, contractions,
  the stressed word last. Length: the segment's word budget from the skeleton (words a minute of planned time at BP-01's heard
  pace, 170).

Animated episodes (shot cards, docs/SHOT_PROMPTS.md KP-16..KP-20): for each shot you play, write `action` as three
present-tense verb phrases (`start` = what the first frame shows, `peak` = the big move with body parts, `settle` = the pose
it holds), `reactions` (one small verb each), the `dialogue` line copied from the script with `to`, and on a narrated shot
the `narration` (what the heroes cannot know; never a description of the picture). A spoken line fits its shot (BP-100: about
7 words in 4 s); keep visible dialogue/lip-sync coverage at or under 5 s. Longer spoken text may be reassigned to narration or split into motivated dialogue coverage. This dialogue rule does not apply to non-dialogue LTX/action shots, which may run 10-15 s when uninterrupted action is better; do not cut a battle/task shot just to meet the dialogue limit. One speaker per shot.

Then run `python -m explainer_engine.scripting.stage_guard writer before.json after.json` and
`python -m explainer_engine.production validate <script>`: 0 FAIL for PV-12, PV-33 and PV-48 (scene_lint, SC-01..SC-10).
Return the segment's lines only.

## Real people in a scene (D-63, creator 2026-10-20)

When the speakers are real living people, the narrator tells the exchange in reported speech ("O'Leary asks if he can still build things. Musk says he can build anything."), short and in the scene's rhythm; the speakers are never voiced (D-62) and a scene keeps at most one bubble as an accent (PV-56). Plan the end of each exchange as a held face of the last speaker in its mood, then a slow move to the next shot, never a cut straight into other people's talk.

A reported exchange counts as the scene's exchange (SC-05, BP-70, D-65, the creator 2026-10-20 21:14/21:17): name the speaker before his words (BP-95),
at most two speakers reported in one line (BP-96). Frame every exchange (ST-14, BP-90, D-64): narrator setup (who talks, named before his first line, and what brings them there), the exchange, narrator conclusion (what came of it); a segment never ends or opens on a hero line, so two exchanges never touch. A bubble line, when the scene keeps one, is a key phrase within BP-84's cap.

Before you hand a segment over: `python -m explainer_engine.scripting.register_lint <script>` reports 0 RG-01 (a word the AI register owns is a FAIL, BP-140), and `story_lint` shows no ST-20..ST-23 you cannot answer in one line (an and-then chain, a narrator repeating the scene, violence in the first seven seconds, a twist that takes too long to say).


## v4.2 Played Dramatic Scene & Anti-Interruption Contract (Mandatory on /3 and v4.0.0)
1. **Ban Isolated One-Line Character Interruptions (`SC-05`)**:
   - Never drop an isolated 1-line character shout inside narrator exposition without a `scene` contract and a multi-turn response.
   - If a segment is `narration_led`, keep it 100% narrator-voiced.
2. **Complete `scene` Contract (`SC-01..SC-06`, `SC-10`)**:
   - Every segment with character dialogue MUST define `scene: {place, present, pov, want, obstacle_want, value, open_charge, close_charge, turn, exit, surface_topic, real_subject}`.
   - Characters in `present` must be co-present in the same physical `place`; `open_charge != close_charge`; `want != obstacle_want`.
   - Play at least 2 contiguous character turns from at least 2 co-present characters without narrator interruption mid-exchange.
3. **Narrator Hand-Off & Consequence Without Double-Exposition (`ST-14`, `ST-21`)**:
   - Frame every played exchange with narrator setup before and narrator consequence after.
   - Never repeat in narration what the adjacent character line just said (`ST-21`).
